"""
Exports all simulation results, metrics, and Pareto solutions into dashboard/data.js
for instant, standalone, zero-dependency browser rendering.
"""

import json
import numpy as np
import pandas as pd
import shutil
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
RESULTS_DIR = BASE_DIR / "output" / "results"
FIGURES_DIR = BASE_DIR / "output" / "figures"
MODELS_DIR = BASE_DIR / "output" / "models"
DASHBOARD_DIR = BASE_DIR / "dashboard"
DASH_FIGS_DIR = DASHBOARD_DIR / "figures"

DASHBOARD_DIR.mkdir(parents=True, exist_ok=True)
DASH_FIGS_DIR.mkdir(parents=True, exist_ok=True)

# Copy figures to dashboard/figures/
for fig_file in FIGURES_DIR.glob("*.png"):
    shutil.copy(fig_file, DASH_FIGS_DIR / fig_file.name)

# 1. Load JSONs
with open(RESULTS_DIR / "selected_solution_metadata.json") as f:
    selected_meta = json.load(f)

with open(RESULTS_DIR / "forecasting_metrics.json") as f:
    fc_metrics = json.load(f)

with open(RESULTS_DIR / "resilience_metrics.json") as f:
    resilience_metrics = json.load(f)

with open(RESULTS_DIR / "adaptive_metrics.json") as f:
    adaptive_metrics = json.load(f)

with open(MODELS_DIR / "markov_model.json") as f:
    markov_model = json.load(f)

# 2. Load CSVs
replenish_plan = pd.read_csv(RESULTS_DIR / "selected_replenishment_plan.csv").to_dict(orient='records')
logistics_schedule = pd.read_csv(RESULTS_DIR / "logistics_shipment_schedule.csv").to_dict(orient='records')
pareto_df = pd.read_csv(RESULTS_DIR / "pareto_front_objectives.csv").to_dict(orient='records')
disruption_res = pd.read_csv(RESULTS_DIR / "disruption_resilience_evaluation.csv").to_dict(orient='records')
resilience_traj = pd.read_csv(RESULTS_DIR / "resilience_daily_trajectories.csv").to_dict(orient='records')
adaptive_comp = pd.read_csv(RESULTS_DIR / "adaptive_vs_static_comparison.csv").to_dict(orient='records')
adaptive_traj = pd.read_csv(RESULTS_DIR / "adaptive_daily_trajectories.csv").to_dict(orient='records')
baseline_detailed = pd.read_csv(RESULTS_DIR / "baseline_comparison_detailed.csv").to_dict(orient='records')
baseline_summary = pd.read_csv(RESULTS_DIR / "baseline_comparison_summary.csv").to_dict(orient='records')

# 3. Compact Markov Transition matrices for categories
series_matrices = markov_model["series_transition_matrices"]
cat_matrices = {
    "Global": markov_model["global_transition_matrix"],
    "FOODS": np.round(np.mean([np.array(m) for k, m in series_matrices.items() if "FOODS" in k], axis=0), 3).tolist(),
    "HOUSEHOLD": np.round(np.mean([np.array(m) for k, m in series_matrices.items() if "HOUSEHOLD" in k], axis=0), 3).tolist(),
    "HOBBIES": np.round(np.mean([np.array(m) for k, m in series_matrices.items() if "HOBBIES" in k], axis=0), 3).tolist(),
}

# 4. Sample 28-day forecasting trajectory for CA_1 aggregate
pred_df = pd.read_parquet(RESULTS_DIR / "forecasting_test_predictions.parquet")
ca_pred = pred_df[pred_df['store_id'] == 'CA_1'].groupby('date')[['demand', 'y_pred_markov', 'y_pred_base']].sum().reset_index()
fc_trace = {
    "dates": [str(d)[:10] for d in ca_pred['date']],
    "actual": np.round(ca_pred['demand'].values, 1).tolist(),
    "markov_xgboost": np.round(ca_pred['y_pred_markov'].values, 1).tolist(),
    "baseline_xgboost": np.round(ca_pred['y_pred_base'].values, 1).tolist()
}

dashboard_data = {
    "selected_metadata": selected_meta,
    "forecasting_metrics": fc_metrics,
    "resilience_metrics": resilience_metrics,
    "adaptive_metrics": adaptive_metrics,
    "markov_matrices": cat_matrices,
    "forecast_trace": fc_trace,
    "replenishment_plan": replenish_plan,
    "logistics_schedule": logistics_schedule,
    "pareto_solutions": pareto_df,
    "disruption_scenarios": disruption_res,
    "resilience_trajectories": resilience_traj,
    "adaptive_comparison": adaptive_comp,
    "adaptive_trajectories": adaptive_traj,
    "baseline_detailed": baseline_detailed,
    "baseline_summary": baseline_summary
}

# Write JS file
js_content = f"// Generated data bundle for Supply Chain Decision-Support Dashboard\nconst DASHBOARD_DATA = {json.dumps(dashboard_data, indent=2)};\n"
(DASHBOARD_DIR / "data.js").write_text(js_content, encoding='utf-8')
print("Successfully generated dashboard/data.js and copied figures!")
