"""
Step 7: Feasible Inventory & Logistics Decision Selection
Selects an operationally feasible compromise solution from the Pareto frontier.
Technique:
- Constraint-based operational filtering (e.g., Service Level >= 95%, Fill Rate >= 95%)
- TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) multi-criteria ranking
- Knee-point trade-off analysis
- Synthesis of actionable supply chain execution plan:
  * Replenishment order quantities per SKU-store
  * Store-level inventory allocation
  * Multi-echelon logistics dispatch schedule (truckload allocation, utilization, delivery ETA)
"""

import numpy as np
import pandas as pd
import json
import logging
from pathlib import Path
from src.config import (
    RESULTS_DIR, SUPPLY_CHAIN_CONFIG
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def run_topsis(
    matrix,
    weights=None,
    criteria_types=None
):
    """
    Applies TOPSIS on objective matrix.
    criteria_types: 1 for maximization, -1 for minimization.
    """
    m, n = matrix.shape
    if weights is None:
        weights = np.ones(n) / n
    else:
        weights = np.array(weights) / np.sum(weights)

    if criteria_types is None:
        criteria_types = np.ones(n)

    # 1. Vector normalization
    norm_factors = np.sqrt(np.sum(matrix ** 2, axis=0))
    norm_factors = np.where(norm_factors == 0, 1.0, norm_factors)
    R = matrix / norm_factors

    # 2. Weighted normalized matrix
    V = R * weights[None, :]

    # 3. Positive ideal (A+) and negative ideal (A-)
    A_plus = np.zeros(n)
    A_minus = np.zeros(n)
    for j in range(n):
        if criteria_types[j] == 1:  # Benefit (maximize)
            A_plus[j] = np.max(V[:, j])
            A_minus[j] = np.min(V[:, j])
        else:  # Cost (minimize)
            A_plus[j] = np.min(V[:, j])
            A_minus[j] = np.max(V[:, j])

    # 4. Separation distances
    S_plus = np.sqrt(np.sum((V - A_plus[None, :]) ** 2, axis=1))
    S_minus = np.sqrt(np.sum((V - A_minus[None, :]) ** 2, axis=1))

    # 5. Relative closeness to ideal
    denom = S_plus + S_minus
    denom = np.where(denom == 0, 1e-6, denom)
    C = S_minus / denom

    return C, S_plus, S_minus


def select_feasible_decision(
    pareto_csv=None,
    pareto_npz=None,
    min_service_level=0.92,
    min_fill_rate=0.95
):
    """
    Filters and selects optimal operating solution from Pareto front.
    """
    logger.info("=== Starting Step 7: Feasible Decision Selection ===")
    if pareto_csv is None:
        pareto_csv = RESULTS_DIR / "pareto_front_objectives.csv"
    if pareto_npz is None:
        pareto_npz = RESULTS_DIR / "pareto_solutions.npz"

    df_pareto = pd.read_csv(pareto_csv)
    data_npz = np.load(pareto_npz, allow_pickle=True)
    X_pareto = data_npz['X_pareto']
    item_keys = data_npz['item_keys']
    stores = data_npz['stores']

    logger.info("Loaded %d Pareto front candidates.", len(df_pareto))

    # 1. Constraint-Based Filtering
    # Filter candidates satisfying operational requirements
    feasible_mask = (
        (df_pareto['Service_Level'] >= min_service_level) &
        (df_pareto['Demand_Fulfillment'] >= min_fill_rate)
    )

    if not np.any(feasible_mask):
        logger.warning("Strict service thresholds (SL>=%.2f, FR>=%.2f) yielded 0 candidates; relaxing to Pareto top 30%%.",
                       min_service_level, min_fill_rate)
        feasible_mask = df_pareto['Service_Level'] >= df_pareto['Service_Level'].quantile(0.60)

    feasible_indices = np.where(feasible_mask)[0]
    df_feasible = df_pareto.iloc[feasible_indices].copy().reset_index()

    logger.info("Feasible candidate pool: %d solutions.", len(df_feasible))

    # 2. Multi-Criteria TOPSIS Evaluation
    # Objectives in order: Holding_Cost, Ordering_Cost, Transportation_Cost, Stockout_Cost, Service_Level, Demand_Fulfillment
    obj_cols = ['Holding_Cost', 'Ordering_Cost', 'Transportation_Cost', 'Stockout_Cost', 'Service_Level', 'Demand_Fulfillment']
    matrix = df_feasible[obj_cols].values

    # Cost objectives (-1: minimize), Benefit objectives (+1: maximize)
    criteria_types = np.array([-1, -1, -1, -1, 1, 1])
    # Strategic Weights: balanced emphasis on service assurance and cost efficiency
    weights = np.array([0.15, 0.10, 0.15, 0.15, 0.25, 0.20])

    topsis_scores, s_plus, s_minus = run_topsis(matrix, weights, criteria_types)
    df_feasible['topsis_score'] = topsis_scores

    # Identify best compromise solution
    best_feasible_loc = int(np.argmax(topsis_scores))
    best_solution_meta = df_feasible.iloc[best_feasible_loc]
    best_pareto_idx = int(best_solution_meta['index'])

    logger.info("Best Compromise Solution Selected (Pareto Solution #%d, TOPSIS Score: %.4f):",
                best_pareto_idx, best_solution_meta['topsis_score'])
    for col in obj_cols + ['Total_Cost']:
        logger.info("  %-22s: %10.2f", col, best_solution_meta[col])

    # 3. Extract Chosen Decision Vector X* (Replenishment quantities)
    best_X = X_pareto[best_pareto_idx]

    # 4. Formulate Detailed Operational Replenishment & Inventory Plan
    inv_df = pd.read_parquet(RESULTS_DIR / "dynamic_inventory_requirements.parquet")
    latest_inv = inv_df.groupby(['store_id', 'item_id']).last().reset_index()

    plan_rows = []
    for i, key in enumerate(item_keys):
        st, it = key.split('_', 1) if '_' in key else (stores[i], key)
        # Match store and item
        match = latest_inv[(latest_inv['store_id'] == stores[i]) & (latest_inv['item_id'] == it)]
        if len(match) == 0:
            match = latest_inv[latest_inv['item_id'] == it]

        s_price = float(match['sell_price'].iloc[0]) if len(match) > 0 else 5.0
        daily_d = float(match['forecast_daily_demand'].iloc[0]) if len(match) > 0 else 10.0
        ss = float(match['safety_stock'].iloc[0]) if len(match) > 0 else 15.0
        rop = float(match['reorder_point'].iloc[0]) if len(match) > 0 else 30.0

        q_recommended = float(np.round(best_X[i]))
        initial_stock = float(np.round(ss * 0.75))
        avail_stock = initial_stock + q_recommended

        plan_rows.append({
            'store_id': stores[i],
            'item_id': it,
            'sell_price': s_price,
            'forecast_daily_demand': daily_d,
            'cycle_expected_demand': round(daily_d * 7, 1),
            'initial_on_hand': initial_stock,
            'recommended_order_qty': q_recommended,
            'available_post_replenish': avail_stock,
            'safety_stock_target': ss,
            'reorder_point': rop,
            'projected_end_inventory': max(0.0, avail_stock - daily_d * 7),
            'stockout_projected': int(avail_stock < daily_d * 7)
        })

    replenish_plan = pd.DataFrame(plan_rows)
    replenish_plan.to_csv(RESULTS_DIR / "selected_replenishment_plan.csv", index=False)

    # 5. Formulate Logistics Shipment & Dispatch Schedule
    truck_cap = SUPPLY_CHAIN_CONFIG['truck_capacity_units']
    distances = SUPPLY_CHAIN_CONFIG['distances_km']
    transit_cost_km = SUPPLY_CHAIN_CONFIG['transit_cost_per_km']
    lead_times = SUPPLY_CHAIN_CONFIG['lead_times']

    shipment_summary = []
    for s_id in sorted(list(set(stores))):
        s_orders = replenish_plan[replenish_plan['store_id'] == s_id]['recommended_order_qty'].sum()
        s_skus_ordered = (replenish_plan[(replenish_plan['store_id'] == s_id) & (replenish_plan['recommended_order_qty'] > 0)]).shape[0]
        num_trucks = int(np.ceil(s_orders / truck_cap))
        dist = distances.get(s_id, 500)
        t_cost = num_trucks * dist * transit_cost_km
        lt = lead_times.get(s_id, 3)
        utilization = (s_orders / (num_trucks * truck_cap) * 100) if num_trucks > 0 else 0

        shipment_summary.append({
            'destination_store': s_id,
            'total_units_dispatched': s_orders,
            'active_skus_replenished': s_skus_ordered,
            'trucks_required': num_trucks,
            'fleet_capacity_units': num_trucks * truck_cap,
            'fleet_utilization_pct': round(utilization, 1),
            'transit_distance_km': dist,
            'lead_time_days': lt,
            'transportation_cost_usd': round(t_cost, 2),
            'dispatch_priority': 'High' if utilization > 80 else 'Standard'
        })

    shipment_df = pd.DataFrame(shipment_summary)
    shipment_df.to_csv(RESULTS_DIR / "logistics_shipment_schedule.csv", index=False)

    logger.info("Logistics Dispatch Schedule Generated:\n%s", shipment_df.to_string())

    selection_metadata = {
        "selected_pareto_index": best_pareto_idx,
        "topsis_score": round(float(best_solution_meta['topsis_score']), 4),
        "total_cost": round(float(best_solution_meta['Total_Cost']), 2),
        "holding_cost": round(float(best_solution_meta['Holding_Cost']), 2),
        "ordering_cost": round(float(best_solution_meta['Ordering_Cost']), 2),
        "transportation_cost": round(float(best_solution_meta['Transportation_Cost']), 2),
        "stockout_cost": round(float(best_solution_meta['Stockout_Cost']), 2),
        "service_level_pct": round(float(best_solution_meta['Service_Level'] * 100), 2),
        "demand_fulfillment_pct": round(float(best_solution_meta['Demand_Fulfillment'] * 100), 2),
        "total_replenishment_units": float(replenish_plan['recommended_order_qty'].sum()),
        "total_trucks_dispatched": int(shipment_df['trucks_required'].sum())
    }

    with open(RESULTS_DIR / "selected_solution_metadata.json", "w") as f:
        json.dump(selection_metadata, f, indent=2)

    return best_solution_meta, replenish_plan, shipment_df, selection_metadata


if __name__ == "__main__":
    sol, r_plan, s_plan, meta = select_feasible_decision()
    print("Step 7 completed successfully.")
    print("Selected Solution Metadata:", meta)
