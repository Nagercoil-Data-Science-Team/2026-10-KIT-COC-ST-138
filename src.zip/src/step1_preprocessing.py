"""
Step 1: Data Preprocessing
Prepares leakage-free and standardized product-store demand sequences.
Techniques:
- Data extraction & melting
- Calendar & price alignment
- Missing-value imputation
- Duplicate verification & removal
- Outlier treatment (robust percentile clipping)
- Chronological sorting & validation
"""

import pandas as pd
import numpy as np
import logging
from pathlib import Path
from src.config import (
    CALENDAR_PATH, SALES_PATH, PRICES_PATH,
    TARGET_STORES, TARGET_ITEMS, START_DAY, END_DAY,
    PREPROCESSED_DIR
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def preprocess_data(
    target_stores=TARGET_STORES,
    target_items=TARGET_ITEMS,
    start_day=START_DAY,
    end_day=END_DAY,
    output_path=None
):
    """
    Executes Step 1 pipeline and outputs clean product-store time series.
    """
    logger.info("=== Starting Step 1: Data Preprocessing ===")

    # 1. Load Calendar
    logger.info("Loading calendar data from %s", CALENDAR_PATH)
    calendar_df = pd.read_csv(CALENDAR_PATH)
    calendar_df['date'] = pd.to_datetime(calendar_df['date'])

    # Fill event nulls
    calendar_df['event_name_1'] = calendar_df['event_name_1'].fillna('None')
    calendar_df['event_type_1'] = calendar_df['event_type_1'].fillna('None')
    calendar_df['event_name_2'] = calendar_df['event_name_2'].fillna('None')
    calendar_df['event_type_2'] = calendar_df['event_type_2'].fillna('None')
    calendar_df['has_event_1'] = (calendar_df['event_name_1'] != 'None').astype(int)
    calendar_df['has_event_2'] = (calendar_df['event_name_2'] != 'None').astype(int)

    # 2. Load and Filter Sales Data
    logger.info("Loading sales data from %s", SALES_PATH)
    id_cols = ['id', 'item_id', 'dept_id', 'cat_id', 'store_id', 'state_id']
    day_cols = [f"d_{d}" for d in range(start_day, end_day + 1)]
    use_cols = id_cols + day_cols

    # Read sales data filtered by items and stores
    sales_df = pd.read_csv(SALES_PATH, usecols=use_cols)
    filtered_sales = sales_df[
        sales_df['store_id'].isin(target_stores) &
        sales_df['item_id'].isin(target_items)
    ].copy()

    logger.info("Filtered sales shape: %s (%d product-store series)",
                filtered_sales.shape, len(filtered_sales))

    # 3. Melt to Long Format
    logger.info("Melting wide sales matrix into longitudinal time series...")
    melted_df = pd.melt(
        filtered_sales,
        id_vars=id_cols,
        value_vars=day_cols,
        var_name='d',
        value_name='demand'
    )
    melted_df['demand'] = melted_df['demand'].astype(float)
    logger.info("Melted records count: %d", len(melted_df))

    # 4. Merge with Calendar
    logger.info("Aligning calendar and event schedules...")
    merged_df = pd.merge(melted_df, calendar_df, on='d', how='left')

    # State SNAP flag assignment
    merged_df['snap_flag'] = 0
    for state in ['CA', 'TX', 'WI']:
        mask = merged_df['state_id'] == state
        merged_df.loc[mask, 'snap_flag'] = merged_df.loc[mask, f'snap_{state}']

    # Drop unneeded snap columns
    merged_df.drop(columns=['snap_CA', 'snap_TX', 'snap_WI'], inplace=True)

    # 5. Merge with Sell Prices
    logger.info("Loading and joining sell prices from %s", PRICES_PATH)
    prices_df = pd.read_csv(PRICES_PATH)
    # Filter prices to relevant stores and items
    prices_filtered = prices_df[
        prices_df['store_id'].isin(target_stores) &
        prices_df['item_id'].isin(target_items)
    ]
    merged_df = pd.merge(
        merged_df,
        prices_filtered,
        on=['store_id', 'item_id', 'wm_yr_wk'],
        how='left'
    )

    # 6. Missing Value Imputation
    logger.info("Performing missing-value imputation on prices...")
    missing_prices_before = merged_df['sell_price'].isna().sum()
    # Sort for forward fill per item-store
    merged_df.sort_values(by=['store_id', 'item_id', 'date'], inplace=True)
    merged_df['sell_price'] = (
        merged_df.groupby(['store_id', 'item_id'])['sell_price']
        .transform(lambda g: g.ffill().bfill())
    )
    # Global fallback by item_id mean if still missing
    if merged_df['sell_price'].isna().sum() > 0:
        merged_df['sell_price'] = (
            merged_df.groupby('item_id')['sell_price']
            .transform(lambda g: g.fillna(g.mean()))
        )
    logger.info("Missing prices imputed: %d -> %d",
                missing_prices_before, merged_df['sell_price'].isna().sum())

    # 7. Duplicate Removal & Verification
    duplicates_count = merged_df.duplicated(subset=['store_id', 'item_id', 'date']).sum()
    if duplicates_count > 0:
        logger.warning("Found %d duplicate records; removing duplicates...", duplicates_count)
        merged_df.drop_duplicates(subset=['store_id', 'item_id', 'date'], keep='first', inplace=True)
    else:
        logger.info("Duplicate check passed: 0 duplicates found.")

    # 8. Outlier Treatment (Robust Percentile Clipping per series)
    logger.info("Applying outlier treatment (99.5th percentile clipping per product-store)...")
    def cap_outliers(series):
        upper_limit = series.quantile(0.995)
        # Only cap if upper_limit > 5 to avoid suppressing legitimate variation in low-demand goods
        if upper_limit > 5:
            return np.clip(series, 0, upper_limit)
        return series

    merged_df['demand_raw'] = merged_df['demand']
    merged_df['demand'] = (
        merged_df.groupby(['store_id', 'item_id'])['demand']
        .transform(cap_outliers)
    )

    # 9. Chronological Sorting & Clean Index
    merged_df.sort_values(by=['store_id', 'item_id', 'date'], inplace=True)
    merged_df.reset_index(drop=True, inplace=True)

    # 10. Save Output
    if output_path is None:
        output_path = PREPROCESSED_DIR / "clean_sales_data.parquet"
    merged_df.to_parquet(output_path, index=False)
    logger.info("Clean dataset saved to %s with shape: %s", output_path, merged_df.shape)

    return merged_df


if __name__ == "__main__":
    df = preprocess_data()
    print("Preprocessing completed. Columns:")
    print(df.columns.tolist())
    print("Sample records:")
    print(df[['date', 'store_id', 'item_id', 'demand', 'sell_price', 'has_event_1', 'snap_flag']].head())
