"""
Configuration file for Hybrid Markov-Based Multi-Objective Optimization Framework
for Real-Time Forecasting, Inventory, Logistics, and Resilient Supply Chain Management.
Dataset: M5 Walmart Forecasting Dataset
"""

import os
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
PREPROCESSED_DIR = OUTPUT_DIR / "preprocessed"
MODELS_DIR = OUTPUT_DIR / "models"
RESULTS_DIR = OUTPUT_DIR / "results"
FIGURES_DIR = OUTPUT_DIR / "figures"

# Ensure all directories exist
for d in [PREPROCESSED_DIR, MODELS_DIR, RESULTS_DIR, FIGURES_DIR]:
    os.makedirs(d, exist_ok=True)

# Data files
CALENDAR_PATH = DATA_DIR / "calendar.csv"
SALES_PATH = DATA_DIR / "sales_train_validation.csv"
PRICES_PATH = DATA_DIR / "sell_prices.csv"

# Representative Supply Chain Network Selection
# Selecting 30 high-activity representative items across 3 categories (FOODS, HOUSEHOLD, HOBBIES)
# and across 3 geographic states (CA_1, TX_1, WI_1) -> 90 product-store echelon nodes
TARGET_STORES = ["CA_1", "TX_1", "WI_1"]

TARGET_ITEMS = [
    # FOODS (Perishable / high velocity)
    "FOODS_3_090", "FOODS_3_586", "FOODS_3_120", "FOODS_1_096", "FOODS_3_252",
    "FOODS_3_282", "FOODS_3_681", "FOODS_3_226", "FOODS_3_070", "FOODS_3_555",
    # HOUSEHOLD (Medium velocity / staple goods)
    "HOUSEHOLD_1_459", "HOUSEHOLD_1_110", "HOUSEHOLD_1_334", "HOUSEHOLD_1_118", "HOUSEHOLD_1_465",
    "HOUSEHOLD_2_440", "HOUSEHOLD_1_418", "HOUSEHOLD_1_447", "HOUSEHOLD_1_096", "HOUSEHOLD_1_303",
    # HOBBIES (Lower velocity / durable goods)
    "HOBBIES_1_234", "HOBBIES_1_354", "HOBBIES_1_158", "HOBBIES_1_048", "HOBBIES_1_254",
    "HOBBIES_1_268", "HOBBIES_1_189", "HOBBIES_1_008", "HOBBIES_1_233", "HOBBIES_1_371"
]

# Time horizon configuration
# M5 sales dataset covers d_1 to d_1913
# We use the recent 730 days (2 full years, d_1184 to d_1913) for optimal training & test
START_DAY = 1184
END_DAY = 1913
TRAIN_TEST_SPLIT_DAY = 1885  # Final 28 days (d_1886 to d_1913) as out-of-sample test set (standard Kaggle horizon)

# Markov demand state configuration (percentile thresholds)
MARKOV_STATES = ["Low", "Normal", "High", "Peak"]
MARKOV_PERCENTILES = {
    "Low": (0.0, 0.25),
    "Normal": (0.25, 0.50),
    "High": (0.50, 0.75),
    "Peak": (0.75, 1.0)
}

# Supply Chain & Logistics Cost & Operational Parameters
SUPPLY_CHAIN_CONFIG = {
    "lead_times": {
        "CA_1": 2,  # days from Central Distribution Center
        "TX_1": 3,
        "WI_1": 4
    },
    "distances_km": {
        "CA_1": 450,
        "TX_1": 850,
        "WI_1": 1200
    },
    # Holding cost rate (% of item sell price per day)
    "holding_cost_rate": 0.005,
    # Fixed ordering cost per replenishment order batch ($)
    "ordering_cost_fixed": 65.0,
    # Unit stockout penalty cost multiplier (relative to item sell price)
    "stockout_penalty_multiplier": 2.2,
    # Logistics transportation cost: $ per km per truck
    "transit_cost_per_km": 1.45,
    # Truckload capacity in units
    "truck_capacity_units": 1500,
    # Store warehouse capacity in units
    "store_warehouse_capacity": {
        "CA_1": 120000,
        "TX_1": 100000,
        "WI_1": 90000
    },
    # Target nominal cycle service level (e.g., 95%)
    "target_service_level": 0.95,
    "z_score_95": 1.645,
    "z_score_99": 2.326
}

# NSGA-II Multi-Objective Optimization Configuration
NSGA2_CONFIG = {
    "pop_size": 80,
    "n_gen": 80,
    "crossover_prob": 0.9,
    "mutation_prob": 0.15,
    "seed": 42
}
