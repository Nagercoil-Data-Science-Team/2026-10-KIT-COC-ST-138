"""
Step 5: Dynamic Inventory Requirement Estimation
Translates forecasted demand uncertainty and Markov demand regimes into dynamic inventory requirements.
Techniques:
- Lead-time demand estimation: D_L = L * y_pred
- Markov regime volatility risk multiplier: omega(S_t)
- Dynamic Safety Stock calculation:
  SS_t = Z_alpha * sqrt(L * sigma_e^2 + y_pred^2 * sigma_L^2) * omega(S_t)
- Dynamic Reorder Point: ROP_t = D_L,t + SS_t
- Dynamic Target Inventory (Order-up-to level): S_t = ROP_t + EOQ_t
- Probabilistic Stockout and Excess-Inventory Risk Estimation
Output: Dynamic safety stock, reorder point, EOQ, target inventory, and risk profiles.
"""

import pandas as pd
import numpy as np
import json
import logging
from scipy.stats import norm
from pathlib import Path
from src.config import (
    RESULTS_DIR, SUPPLY_CHAIN_CONFIG
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def compute_dynamic_inventory_requirements(
    predictions_path=None,
    residuals_path=None,
    output_path=None
):
    """
    Computes dynamic safety stock, ROP, target inventory, and risk curves for all items and stores.
    """
    logger.info("=== Starting Step 5: Dynamic Inventory Requirement Estimation ===")
    if predictions_path is None:
        predictions_path = RESULTS_DIR / "forecasting_test_predictions.parquet"
    if residuals_path is None:
        residuals_path = RESULTS_DIR / "series_residuals.csv"
    if output_path is None:
        output_path = RESULTS_DIR / "dynamic_inventory_requirements.parquet"

    df = pd.read_parquet(predictions_path)
    residuals_df = pd.read_csv(residuals_path)

    # Merge series residual standard deviation (sigma_e)
    df = pd.merge(df, residuals_df[['store_id', 'item_id', 'residual_std']], on=['store_id', 'item_id'], how='left')
    df['residual_std'] = df['residual_std'].fillna(df['residual_std'].median())
    # Ensure minimum sigma_e to prevent zero division
    df['residual_std'] = df['residual_std'].clip(lower=0.5)

    lead_times = SUPPLY_CHAIN_CONFIG['lead_times']
    holding_rate = SUPPLY_CHAIN_CONFIG['holding_cost_rate']
    k_order = SUPPLY_CHAIN_CONFIG['ordering_cost_fixed']
    z_alpha = SUPPLY_CHAIN_CONFIG['z_score_95']  # 1.645 for 95% CSL
    sigma_L = 0.35  # stochastic lead time variance in days

    # 1. Assign Store-Specific Lead Time
    df['lead_time'] = df['store_id'].map(lead_times).fillna(3).astype(float)

    # 2. Lead Time Demand (D_L)
    df['forecast_daily_demand'] = df['y_pred_markov'].clip(lower=0.1)
    df['lead_time_demand'] = df['lead_time'] * df['forecast_daily_demand']

    # 3. Markov State Volatility / Risk Multiplier omega(S_t)
    # Peak state or high transition probability to Peak gets higher buffer
    def calculate_markov_risk_multiplier(row):
        state = row.get('markov_state', 1)
        p_peak = row.get('prob_trans_peak', 0.25)

        base_multiplier = {0: 0.82, 1: 1.00, 2: 1.18, 3: 1.35}.get(state, 1.0)
        # Adjust upward if transition to Peak is anticipated
        if p_peak > 0.35:
            base_multiplier += 0.12
        return base_multiplier

    df['markov_risk_multiplier'] = df.apply(calculate_markov_risk_multiplier, axis=1)

    # 4. Dynamic Safety Stock (SS)
    # Combined variance: Var(D_L) = L * sigma_e^2 + (y_pred)^2 * sigma_L^2
    var_lead_time_demand = (
        df['lead_time'] * (df['residual_std'] ** 2) +
        (df['forecast_daily_demand'] ** 2) * (sigma_L ** 2)
    )
    df['std_lead_time_demand'] = np.sqrt(var_lead_time_demand)
    df['safety_stock'] = (
        z_alpha * df['std_lead_time_demand'] * df['markov_risk_multiplier']
    ).round(1)

    # 5. Dynamic Reorder Point (ROP)
    df['reorder_point'] = (df['lead_time_demand'] + df['safety_stock']).round(1)

    # 6. Dynamic EOQ (Economic Order Quantity)
    # Annualized or 30-day cycle EOQ
    df['unit_holding_cost'] = (df['sell_price'] * holding_rate).clip(lower=0.01)
    df['eoq'] = np.sqrt(
        (2.0 * k_order * df['forecast_daily_demand'] * 30.0) / df['unit_holding_cost']
    ).round(1).clip(lower=10.0)

    # 7. Target Inventory (Order-Up-To Level S)
    df['target_inventory'] = (df['reorder_point'] + df['eoq']).round(1)

    # 8. Operational Risk Estimation (Simulating current on-hand inventory around ROP)
    # Probability of stockout if inventory equals ROP vs if inventory drops below ROP
    stockout_z = (df['safety_stock'] / (df['std_lead_time_demand'] + 1e-4))
    df['stockout_risk_at_rop'] = (1.0 - norm.cdf(stockout_z)).round(4)

    # Save output
    df.to_parquet(output_path, index=False)
    logger.info("Dynamic Inventory Requirements generated: %d records saved to %s", len(df), output_path)

    # Summarize across categories
    summary = df.groupby('cat_id')[['forecast_daily_demand', 'safety_stock', 'reorder_point', 'eoq', 'target_inventory']].mean().reset_index()
    logger.info("Average Inventory Parameters by Category:\n%s", summary.to_string())

    summary.to_csv(RESULTS_DIR / "inventory_category_summary.csv", index=False)
    return df, summary


if __name__ == "__main__":
    df_inv, summ = compute_dynamic_inventory_requirements()
    print("Step 5 completed successfully.")
    print(summ)
