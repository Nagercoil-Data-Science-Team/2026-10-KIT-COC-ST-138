"""
Step 3: Markov Demand-State Modeling
Represents demand uncertainty through discrete stochastic demand regimes.
Techniques:
- Percentile-based state discretization:
  * Low: Demand < 25th percentile
  * Normal: 25th <= Demand < 50th percentile
  * High: 50th <= Demand < 75th percentile
  * Peak: Demand >= 75th percentile
- Empirical transition-probability matrix estimation with Laplace smoothing
- Stationary distribution derivation
- Conditional expected demand per regime
- Markov feature extraction: State probabilities P(S_{t+1}|S_t) and expected regime demand.
Output: Low, Normal, High, Peak states, Markov transition matrices, and augmented dataset.
"""

import pandas as pd
import numpy as np
import json
import logging
from pathlib import Path
from src.config import (
    PREPROCESSED_DIR, MODELS_DIR, RESULTS_DIR,
    TRAIN_TEST_SPLIT_DAY, MARKOV_STATES
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


class MarkovDemandModel:
    def __init__(self, smoothing=1.0):
        self.smoothing = smoothing
        self.state_names = MARKOV_STATES  # ["Low", "Normal", "High", "Peak"]
        self.series_quantiles = {}
        self.series_transition_matrices = {}
        self.series_state_means = {}
        self.global_quantiles = None
        self.global_transition_matrix = None
        self.global_stationary_dist = None
        self.global_state_means = None

    def fit(self, df_train):
        """
        Fits Markov demand states and transition matrices on training data.
        """
        logger.info("Fitting Markov demand states on training partition (%d records)...", len(df_train))

        # 1. Global quantiles
        q25 = float(df_train['demand'].quantile(0.25))
        q50 = float(df_train['demand'].quantile(0.50))
        q75 = float(df_train['demand'].quantile(0.75))

        # Ensure distinct thresholds if zero-demand occurs frequently
        if q50 <= q25:
            q50 = q25 + 1.0
        if q75 <= q50:
            q75 = q50 + 1.0
        self.global_quantiles = [q25, q50, q75]

        # 2. Fit per product-store series
        grouped = df_train.groupby(['store_id', 'item_id'])
        all_transitions = []

        for (store_id, item_id), group in grouped:
            series_key = f"{store_id}_{item_id}"
            demands = group['demand'].values

            # Series-level quantiles
            sq25 = float(np.percentile(demands, 25))
            sq50 = float(np.percentile(demands, 50))
            sq75 = float(np.percentile(demands, 75))

            # Adjust if identical
            if sq50 <= sq25:
                sq50 = sq25 + 0.5
            if sq75 <= sq50:
                sq75 = sq50 + 0.5
            self.series_quantiles[series_key] = [sq25, sq50, sq75]

            # Discretize series into states 0, 1, 2, 3
            states = self._discretize(demands, [sq25, sq50, sq75])

            # Transition count matrix 4x4
            count_matrix = np.zeros((4, 4), dtype=float)
            for t in range(len(states) - 1):
                s_from = states[t]
                s_to = states[t + 1]
                count_matrix[s_from, s_to] += 1.0
                all_transitions.append((s_from, s_to))

            # Add Laplace smoothing and normalize
            smoothed_counts = count_matrix + self.smoothing
            trans_prob = smoothed_counts / smoothed_counts.sum(axis=1, keepdims=True)
            self.series_transition_matrices[series_key] = trans_prob.tolist()

            # State conditional means
            state_means = []
            for s_idx in range(4):
                mask = (states == s_idx)
                state_means.append(float(np.mean(demands[mask])) if np.any(mask) else float(sq50))
            self.series_state_means[series_key] = state_means

        # 3. Global transition matrix
        global_counts = np.zeros((4, 4), dtype=float)
        for s_from, s_to in all_transitions:
            global_counts[s_from, s_to] += 1.0
        smoothed_global = global_counts + self.smoothing
        self.global_transition_matrix = (smoothed_global / smoothed_global.sum(axis=1, keepdims=True)).tolist()

        # Global stationary distribution: pi * P = pi
        P_mat = np.array(self.global_transition_matrix)
        evals, evecs = np.linalg.eig(P_mat.T)
        stationary = np.real(evecs[:, np.isclose(evals, 1.0)])
        if stationary.shape[1] > 0:
            stat_dist = stationary[:, 0] / np.sum(stationary[:, 0])
            self.global_stationary_dist = [max(0.0, float(x)) for x in stat_dist]
            self.global_stationary_dist = [x / sum(self.global_stationary_dist) for x in self.global_stationary_dist]
        else:
            self.global_stationary_dist = [0.25, 0.25, 0.25, 0.25]

        # Global conditional state means
        global_states = self._discretize(df_train['demand'].values, self.global_quantiles)
        g_means = []
        for s_idx in range(4):
            mask = (global_states == s_idx)
            g_means.append(float(np.mean(df_train['demand'].values[mask])) if np.any(mask) else 1.0)
        self.global_state_means = g_means

        logger.info("Markov Model Fitted. Global Transition Matrix:")
        for idx, row in enumerate(self.global_transition_matrix):
            logger.info("State %-6s -> Low: %.3f, Normal: %.3f, High: %.3f, Peak: %.3f",
                        self.state_names[idx], row[0], row[1], row[2], row[3])
        logger.info("Stationary Distribution: %s", self.global_stationary_dist)
        logger.info("State Conditional Means: %s", self.global_state_means)

    def _discretize(self, values, quantiles):
        """Discretizes numeric demand into 0: Low, 1: Normal, 2: High, 3: Peak."""
        q25, q50, q75 = quantiles
        states = np.zeros(len(values), dtype=int)
        states[(values >= q25) & (values < q50)] = 1
        states[(values >= q50) & (values < q75)] = 2
        states[values >= q75] = 3
        return states

    def transform(self, df):
        """
        Augments dataset with Markov demand states, transition probabilities, and expected future regime demand.
        """
        logger.info("Augmenting dataframe (%d rows) with Markov state features...", len(df))
        df_out = df.copy()

        # Preallocate arrays
        n = len(df_out)
        curr_states = np.zeros(n, dtype=int)
        p_trans = np.zeros((n, 4), dtype=float)
        exp_next_demand = np.zeros(n, dtype=float)

        # Iterate series
        grouped = df_out.groupby(['store_id', 'item_id'])
        for (store_id, item_id), group in grouped:
            indices = group.index.values
            series_key = f"{store_id}_{item_id}"

            quantiles = self.series_quantiles.get(series_key, self.global_quantiles)
            trans_mat = np.array(self.series_transition_matrices.get(series_key, self.global_transition_matrix))
            state_means = np.array(self.series_state_means.get(series_key, self.global_state_means))

            # Discretize using lag_1 demand to avoid target leakage!
            # The current state at time t is determined by historical demand at t-1 (or lag_1)
            lag_demands = group['lag_1'].values
            series_states = self._discretize(lag_demands, quantiles)
            curr_states[indices] = series_states

            # Assign transition probabilities from current state
            for i_local, s in enumerate(series_states):
                probs = trans_mat[s]
                p_trans[indices[i_local]] = probs
                exp_next_demand[indices[i_local]] = float(np.dot(probs, state_means))

        df_out['markov_state'] = curr_states
        df_out['markov_state_name'] = [self.state_names[s] for s in curr_states]

        # One-hot encodings for current state
        for idx, state_name in enumerate(self.state_names):
            df_out[f'state_is_{state_name.lower()}'] = (curr_states == idx).astype(int)
            df_out[f'prob_trans_{state_name.lower()}'] = p_trans[:, idx]

        df_out['markov_expected_demand'] = exp_next_demand

        return df_out

    def save(self, filepath):
        """Saves model parameters to JSON."""
        data = {
            "state_names": self.state_names,
            "global_quantiles": self.global_quantiles,
            "global_transition_matrix": self.global_transition_matrix,
            "global_stationary_dist": self.global_stationary_dist,
            "global_state_means": self.global_state_means,
            "series_quantiles": self.series_quantiles,
            "series_transition_matrices": self.series_transition_matrices,
            "series_state_means": self.series_state_means
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)
        logger.info("Saved Markov model to %s", filepath)

    @classmethod
    def load(cls, filepath):
        """Loads model parameters from JSON."""
        with open(filepath, 'r') as f:
            data = json.load(f)
        model = cls()
        model.state_names = data["state_names"]
        model.global_quantiles = data["global_quantiles"]
        model.global_transition_matrix = data["global_transition_matrix"]
        model.global_stationary_dist = data["global_stationary_dist"]
        model.global_state_means = data["global_state_means"]
        model.series_quantiles = data["series_quantiles"]
        model.series_transition_matrices = data["series_transition_matrices"]
        model.series_state_means = data["series_state_means"]
        return model


def run_markov_modeling(input_path=None, output_path=None):
    """Executes Step 3 Markov Demand-State Modeling."""
    logger.info("=== Starting Step 3: Markov Demand-State Modeling ===")
    if input_path is None:
        input_path = PREPROCESSED_DIR / "features_sales_data.parquet"
    if output_path is None:
        output_path = PREPROCESSED_DIR / "markov_features_sales_data.parquet"

    df = pd.read_parquet(input_path)

    # Convert d column to integer for split
    df['d_num'] = df['d'].str.replace('d_', '').astype(int)
    train_mask = df['d_num'] <= TRAIN_TEST_SPLIT_DAY

    model = MarkovDemandModel(smoothing=1.0)
    model.fit(df[train_mask])

    # Save model
    model_save_path = MODELS_DIR / "markov_model.json"
    model.save(model_save_path)

    # Augment entire dataset
    augmented_df = model.transform(df)
    augmented_df.to_parquet(output_path, index=False)
    logger.info("Augmented dataset saved to %s with shape: %s", output_path, augmented_df.shape)

    return model, augmented_df


if __name__ == "__main__":
    m, df_aug = run_markov_modeling()
    print("Markov Modeling completed. New Columns:")
    print([c for c in df_aug.columns if 'markov' in c or 'state' in c or 'prob_trans' in c])
