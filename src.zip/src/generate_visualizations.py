"""
Publication-Quality Visualization Generator for
Hybrid Markov-Based Multi-Objective Optimization Framework
Adheres to strict journal standards:
  - DPI: 800
  - Figure size: (11, 7)
  - Font: Times New Roman, bold, size 18
  - Grid: Removed in all plots
  - Titles: Figure numbers removed from all titles
  - Legends: Clear, well-spaced, zero word overlap
  - 9 Total Plots (6 existing refined + 3 brand-new deep-dive plots)
"""

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import pandas as pd
import json
import sys
from pathlib import Path

# Ensure project root in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.config import (
    RESULTS_DIR, FIGURES_DIR, MODELS_DIR, SUPPLY_CHAIN_CONFIG
)

# Apply requested publication specifications
plt.rcParams['figure.figsize'] = (11, 7)
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 18
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.labelweight'] = 'bold'
plt.rcParams['axes.titleweight'] = 'bold'
plt.rcParams['figure.titleweight'] = 'bold'
plt.rcParams['axes.grid'] = False
plt.rcParams['figure.dpi'] = 800
plt.rcParams['savefig.dpi'] = 800
plt.rcParams['legend.fontsize'] = 13
plt.rcParams['legend.title_fontsize'] = 14


# ==============================================================================
# Plot 1: Markov Transition Matrices
# ==============================================================================
def plot_markov_matrices():
    """Plot 1: Markov Transition Probability Heatmaps across 4 Echelons."""
    with open(MODELS_DIR / "markov_model.json", "r") as f:
        markov_data = json.load(f)

    fig, axes = plt.subplots(2, 2, figsize=(11, 7))
    states = ["Low", "Normal", "High", "Peak"]
    series_matrices = markov_data["series_transition_matrices"]

    cat_matrices = {
        "Global Network": np.array(markov_data["global_transition_matrix"]),
        "FOODS Category": np.mean([np.array(m) for k, m in series_matrices.items() if "FOODS" in k], axis=0),
        "HOUSEHOLD Category": np.mean([np.array(m) for k, m in series_matrices.items() if "HOUSEHOLD" in k], axis=0),
        "HOBBIES Category": np.mean([np.array(m) for k, m in series_matrices.items() if "HOBBIES" in k], axis=0),
    }

    sub_titles = ["Global Network", "FOODS Category", "HOUSEHOLD Category", "HOBBIES Category"]
    ax_list = [axes[0, 0], axes[0, 1], axes[1, 0], axes[1, 1]]

    for idx, (cat_name, ax) in enumerate(zip(sub_titles, ax_list)):
        matrix = cat_matrices[cat_name]
        sns.heatmap(
            matrix,
            annot=True,
            fmt=".2f",
            cmap="Blues",
            cbar=(idx == 1 or idx == 3),
            xticklabels=states,
            yticklabels=states,
            ax=ax,
            vmin=0.0,
            vmax=0.6,
            linewidths=0.8,
            linecolor='white',
            annot_kws={"fontsize": 11, "fontweight": "bold"}
        )
        ax.set_title(cat_name, fontsize=13, fontweight='bold', pad=6)
        ax.grid(False)
        if idx in [2, 3]:
            ax.set_xlabel(r"Next State $S_{t+1}$", fontsize=12, fontweight='bold')
        else:
            ax.set_xlabel("")
        if idx in [0, 2]:
            ax.set_ylabel(r"Current State $S_t$", fontsize=12, fontweight='bold')
        else:
            ax.set_ylabel("")
        ax.tick_params(labelsize=10)

    fig.suptitle("Empirical Markov Demand-State Transition Matrices Across Echelons", fontsize=15, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_path = FIGURES_DIR / "markov_transition_matrices.png"
    plt.savefig(out_path, dpi=800, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out_path}")


# ==============================================================================
# Plot 2: Demand Forecasting Trajectories and Residuals
# ==============================================================================
def plot_forecasting_performance():
    """Plot 2: Demand Forecasting Trajectories and Error Residual Distributions."""
    pred_path = RESULTS_DIR / "forecasting_test_predictions.parquet"
    if not pred_path.exists():
        return
    df = pd.read_parquet(pred_path)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 7))

    # Panel 1: 28-Day Out-of-Sample Time Series (Store CA_1 Aggregate)
    ca_df = df[df['store_id'] == 'CA_1']
    agg_daily = ca_df.groupby('date')[['demand', 'y_pred_markov', 'y_pred_base']].sum().reset_index()
    agg_daily['day_idx'] = range(1, len(agg_daily) + 1)

    ax1.plot(agg_daily['day_idx'], agg_daily['demand'], 'k-o', label='Actual Sales Demand', linewidth=2.4, markersize=5)
    ax1.plot(agg_daily['day_idx'], agg_daily['y_pred_markov'], color='#2563eb', linestyle='--', label='Markov-Enhanced XGBoost', linewidth=2.4)
    ax1.plot(agg_daily['day_idx'], agg_daily['y_pred_base'], color='#dc2626', linestyle=':', label='Baseline Standard XGBoost', linewidth=2.0)
    ax1.set_title("Out-of-Sample Demand Trajectory", fontsize=14, fontweight='bold', pad=8)
    ax1.set_xlabel("Horizon Day (Days 1 to 28)", fontsize=13, fontweight='bold')
    ax1.set_ylabel("Daily Total Demand (Units)", fontsize=13, fontweight='bold')
    ax1.tick_params(labelsize=11)
    ax1.grid(False)
    ax1.legend(loc='upper right', fontsize=10, frameon=True, framealpha=0.95, edgecolor='gray')

    # Panel 2: Error Residual Density Distribution
    res_markov = df['residual_markov']
    res_base = df['demand'] - df['y_pred_base']
    sns.kdeplot(res_markov, ax=ax2, label='Markov-Enhanced XGBoost (WAPE: 37.9%)', color='#2563eb', fill=True, alpha=0.25, linewidth=2.2)
    sns.kdeplot(res_base, ax=ax2, label='Baseline Standard XGBoost (WAPE: 38.0%)', color='#dc2626', fill=True, alpha=0.15, linewidth=2.0)
    ax2.set_xlim(-15, 15)
    ax2.set_title("Forecasting Error Residual Density", fontsize=14, fontweight='bold', pad=8)
    ax2.set_xlabel(r"Forecast Residual ($y - \hat{y}$)", fontsize=13, fontweight='bold')
    ax2.set_ylabel("Probability Density", fontsize=13, fontweight='bold')
    ax2.tick_params(labelsize=11)
    ax2.grid(False)
    ax2.legend(loc='upper right', fontsize=10, frameon=True, framealpha=0.95, edgecolor='gray')

    fig.suptitle("Demand Forecasting Trajectories and Error Residual Distributions", fontsize=15, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_path = FIGURES_DIR / "forecasting_accuracy_comparison.png"
    plt.savefig(out_path, dpi=800, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out_path}")


# ==============================================================================
# Plot 3: NSGA-II Multi-Objective Pareto Frontier
# ==============================================================================
def plot_pareto_front():
    """Plot 3: NSGA-II Multi-Objective Pareto Frontier and TOPSIS Knee-Point Selection."""
    pareto_csv = RESULTS_DIR / "pareto_front_objectives.csv"
    if not pareto_csv.exists():
        return
    df = pd.read_csv(pareto_csv)

    with open(RESULTS_DIR / "selected_solution_metadata.json", "r") as f:
        meta = json.load(f)
    sel_idx = meta["selected_pareto_index"]
    sel_row = df.loc[sel_idx]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 7))

    # Panel 1: Total Cost vs Service Level Trade-Off
    sc1 = ax1.scatter(
        df['Total_Cost'],
        df['Service_Level'] * 100,
        c=df['Demand_Fulfillment'] * 100,
        cmap='viridis',
        s=55,
        alpha=0.85,
        edgecolors='black',
        linewidth=0.5
    )
    # Highlight TOPSIS knee point
    ax1.scatter(
        [sel_row['Total_Cost']],
        [sel_row['Service_Level'] * 100],
        color='#dc2626',
        s=260,
        marker='*',
        zorder=6,
        label=f'TOPSIS Compromise Solution\n(SL: {sel_row["Service_Level"]*100:.1f}%, Cost: ${sel_row["Total_Cost"]:,.0f})'
    )
    ax1.axhline(95.0, color='#d97706', linestyle='--', linewidth=1.8, label='Target Service Level (95.0%)')
    ax1.set_title("Cost vs. Service Level Trade-Off", fontsize=14, fontweight='bold', pad=8)
    ax1.set_xlabel("Total Operating Cost ($)", fontsize=13, fontweight='bold')
    ax1.set_ylabel("Cycle Service Level (%)", fontsize=13, fontweight='bold')
    ax1.tick_params(labelsize=11)
    ax1.grid(False)
    ax1.legend(loc='lower right', fontsize=9.5, frameon=True, framealpha=0.95, edgecolor='gray')

    # Panel 2: Transportation Cost vs Service Level
    sc2 = ax2.scatter(
        df['Transportation_Cost'],
        df['Service_Level'] * 100,
        c=df['Total_Cost'],
        cmap='plasma',
        s=55,
        alpha=0.85,
        edgecolors='black',
        linewidth=0.5
    )
    ax2.scatter(
        [sel_row['Transportation_Cost']],
        [sel_row['Service_Level'] * 100],
        color='#dc2626',
        s=260,
        marker='*',
        zorder=6,
        label=f'Selected Solution\n(Transit: ${sel_row["Transportation_Cost"]:,.0f})'
    )
    ax2.set_title("Logistics Cost vs. Service Level", fontsize=14, fontweight='bold', pad=8)
    ax2.set_xlabel("Transportation Transit Cost ($)", fontsize=13, fontweight='bold')
    ax2.set_ylabel("Cycle Service Level (%)", fontsize=13, fontweight='bold')
    ax2.tick_params(labelsize=11)
    ax2.grid(False)
    ax2.legend(loc='lower right', fontsize=9.5, frameon=True, framealpha=0.95, edgecolor='gray')

    fig.suptitle("NSGA-II Multi-Objective Pareto Frontier and TOPSIS Knee-Point Selection", fontsize=15, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_path = FIGURES_DIR / "pareto_frontier_3d_2d.png"
    plt.savefig(out_path, dpi=800, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out_path}")


# ==============================================================================
# Plot 4: Supply Chain Disruption Resilience Curves
# ==============================================================================
def plot_resilience_trajectories():
    """Plot 4: Dynamic Supply Chain Service-Level Trajectories Under Disruption Stress Scenarios."""
    traj_path = RESULTS_DIR / "resilience_daily_trajectories.csv"
    if not traj_path.exists():
        return
    df = pd.read_csv(traj_path)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 7))

    # Panel 1: Daily Service Level Trajectories
    scenario_styles = [
        ('Nominal_SL', 'Nominal Baseline', 'black', '-', 2.4),
        ('SCEN_1_SL', 'Demand Surge (+60%)', '#ea580c', '--', 2.0),
        ('SCEN_2_SL', 'Supplier Delay (+4 Days)', '#dc2626', '-.', 2.0),
        ('SCEN_3_SL', 'Logistics Delay (+3 Days)', '#9333ea', ':', 2.0),
        ('SCEN_4_SL', 'Inventory Shortage (-50%)', '#16a34a', '--', 2.0),
        ('SCEN_5_SL', 'Compound Stress (Surge + Delay)', '#b91c1c', '-', 2.2)
    ]

    for col, lbl, clr, ls, lw in scenario_styles:
        if col in df.columns:
            ax1.plot(df['Day'], df[col], label=lbl, color=clr, linestyle=ls, linewidth=lw)

    ax1.axvspan(7, 18, color='mistyrose', alpha=0.5, label='Disruption Window (Days 7–18)')
    ax1.axhline(95.0, color='gray', linestyle=':', linewidth=1.5)
    ax1.set_title("Dynamic Service-Level Degradation Trajectories", fontsize=13, fontweight='bold', pad=8)
    ax1.set_xlabel("Simulation Day (Days 1 to 28)", fontsize=12, fontweight='bold')
    ax1.set_ylabel("Realized Service Level (%)", fontsize=12, fontweight='bold')
    ax1.set_ylim(35, 114)
    ax1.set_xlim(1, 28)
    ax1.tick_params(labelsize=10.5)
    ax1.grid(False)
    ax1.legend(loc='upper right', ncol=2, fontsize=8.0, frameon=True, framealpha=0.95, edgecolor='gray', columnspacing=0.8)

    # Panel 2: Severity and Recovery Time Comparison Bar Chart
    scen_csv = RESULTS_DIR / "disruption_resilience_evaluation.csv"
    if scen_csv.exists():
        s_df = pd.read_csv(scen_csv).iloc[1:]  # Exclude nominal
        x = np.arange(len(s_df))
        w = 0.38

        bars1 = ax2.bar(x - w/2, s_df['sl_degradation_pct'], w, label=r'SL Degradation ($\Delta$SL %)', color='#ea580c')
        ax2_right = ax2.twinx()
        bars2 = ax2_right.bar(x + w/2, s_df['recovery_time_days'], w, label='Recovery Duration (Days)', color='#2563eb')

        # Provide ample vertical headroom to prevent legend and bar labels from colliding
        ax2.set_ylim(0, 16.5)
        ax2_right.set_ylim(0, 16.5)

        # Crisp numerical annotations above each bar
        for b in bars1:
            h = b.get_height()
            ax2.text(b.get_x() + b.get_width()/2., h + 0.35, f"{h:.1f}%", ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#ea580c')
        for b in bars2:
            h = b.get_height()
            ax2_right.text(b.get_x() + b.get_width()/2., h + 0.35, f"{int(h)}d", ha='center', va='bottom', fontsize=8.5, fontweight='bold', color='#2563eb')

        ax2.set_xticks(x)
        clean_labels = [name.split('(')[0].strip() for name in s_df['scenario_name']]
        ax2.set_xticklabels(clean_labels, rotation=30, ha='right', fontsize=9.5, fontweight='bold')
        ax2.set_ylabel(r"Service Degradation ($\Delta$SL %)", color='#ea580c', fontsize=11.5, fontweight='bold')
        ax2_right.set_ylabel("Recovery Duration (Days)", color='#2563eb', fontsize=11.5, fontweight='bold')
        ax2.set_title("Disruption Severity vs. Recovery Duration", fontsize=13, fontweight='bold', pad=8)
        ax2.tick_params(labelsize=10)
        ax2_right.tick_params(labelsize=10)
        ax2.grid(False)
        ax2_right.grid(False)

        lines1, labels1 = ax2.get_legend_handles_labels()
        lines2, labels2 = ax2_right.get_legend_handles_labels()
        ax2.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=9.5, frameon=True, framealpha=0.95, edgecolor='gray')

    fig.suptitle("Dynamic Supply Chain Service-Level Trajectories Under Disruption Stress Scenarios", fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_path = FIGURES_DIR / "disruption_resilience_curves.png"
    plt.savefig(out_path, dpi=800, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out_path}")


# ==============================================================================
# Plot 5: Adaptive vs Static Recovery Dynamics
# ==============================================================================
def plot_adaptive_vs_static():
    """Plot 5: Closed-Loop Adaptive Re-Optimization vs Static Decision Policy Under Disruption."""
    traj_path = RESULTS_DIR / "adaptive_daily_trajectories.csv"
    if not traj_path.exists():
        return
    df = pd.read_csv(traj_path)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 7))

    # Panel 1: Service Level Trajectory Post-Disruption
    ax1.plot(df['Day'], df['Static_Service_Level_Pct'], color='#dc2626', linestyle='--', marker='o', label='Static Strategy (Unadjusted)', linewidth=2.4, markersize=5)
    ax1.plot(df['Day'], df['Adaptive_Service_Level_Pct'], color='#16a34a', linestyle='-', marker='s', label='Adaptive Re-Optimization (Proposed)', linewidth=2.6, markersize=5)
    ax1.axvline(4, color='gray', linestyle=':', linewidth=1.8, label='Shock Detected & Re-Opt Triggered')
    ax1.axhline(95.0, color='#2563eb', linestyle='--', linewidth=1.5, label='Target Service Level (95.0%)')
    ax1.set_title("Service Level Trajectory Post-Disruption", fontsize=13, fontweight='bold', pad=8)
    ax1.set_xlabel("Days Since Disruption Onset", fontsize=12, fontweight='bold')
    ax1.set_ylabel("Realized Daily Service Level (%)", fontsize=12, fontweight='bold')
    ax1.set_ylim(48, 102)
    ax1.tick_params(labelsize=10.5)
    ax1.grid(False)
    ax1.legend(loc='lower right', fontsize=9, frameon=True, framealpha=0.95, edgecolor='gray')

    # Panel 2: Echelon Inventory Level Dynamics
    ax2.plot(df['Day'], df['Static_Inventory_Units'], color='#dc2626', linestyle='--', label='Static Policy Available Inventory', linewidth=2.4)
    ax2.plot(df['Day'], df['Adaptive_Inventory_Units'], color='#16a34a', linestyle='-', label='Adaptive Re-Optimized Inventory', linewidth=2.6)
    ax2.axvline(4, color='gray', linestyle=':', linewidth=1.8)
    ax2.set_title("Echelon Network Inventory Stabilization", fontsize=13, fontweight='bold', pad=8)
    ax2.set_xlabel("Days Since Disruption Onset", fontsize=12, fontweight='bold')
    ax2.set_ylabel("Total Inventory Across Network (Units)", fontsize=12, fontweight='bold')
    ax2.tick_params(labelsize=10.5)
    ax2.grid(False)
    ax2.legend(loc='upper left', fontsize=9.5, frameon=True, framealpha=0.95, edgecolor='gray')

    fig.suptitle("Closed-Loop Adaptive Re-Optimization vs Static Decision Policy Under Disruption", fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_path = FIGURES_DIR / "adaptive_vs_static_recovery.png"
    plt.savefig(out_path, dpi=800, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out_path}")


# ==============================================================================
# Plot 6: Cross-Paradigm Benchmark Evaluation
# ==============================================================================
def plot_baseline_radar_and_bars():
    """Plot 6: Comparative Performance Evaluation Across Four Methodological Paradigms."""
    bench_csv = RESULTS_DIR / "baseline_comparison_detailed.csv"
    if not bench_csv.exists():
        return
    df = pd.read_csv(bench_csv)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 7))

    x = np.arange(len(df))
    w = 0.38
    model_labels = ["Traditional\n(ARIMA+EOQ)", "ML Baseline\n(XGB+EOQ)", "Single-Obj Opt\n(XGB+GA)", "Proposed\n(Markov+NSGA2)"]

    # Panel 1: Operating Cost vs Service Level
    bars_cost = ax1.bar(x - w/2, df['Total_Cost_USD'], w, label='Total Operating Cost ($)', color='#334155')
    ax1_right = ax1.twinx()
    bars_sl = ax1_right.bar(x + w/2, df['Service_Level_Pct'], w, label='Cycle Service Level (%)', color='#059669')

    ax1.set_xticks(x)
    ax1.set_xticklabels(model_labels, fontsize=9.5, fontweight='bold')
    ax1.set_ylabel("Total Operating Cost ($)", color='#334155', fontsize=12, fontweight='bold')
    ax1_right.set_ylabel("Cycle Service Level (%)", color='#059669', fontsize=12, fontweight='bold')
    ax1_right.set_ylim(70, 103)
    ax1.set_title("Operating Cost vs. Service Level", fontsize=13, fontweight='bold', pad=8)
    ax1.tick_params(labelsize=10)
    ax1_right.tick_params(labelsize=10)
    ax1.grid(False)
    ax1_right.grid(False)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax1_right.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=9.5, frameon=True, framealpha=0.95, edgecolor='gray')

    # Panel 2: Recovery Duration and Resilience Index
    bars_rec = ax2.bar(x - w/2, df['Recovery_Time_Days'], w, label='Recovery Duration (Days)', color='#2563eb')
    ax2_right = ax2.twinx()
    bars_res = ax2_right.bar(x + w/2, df['Resilience_Index'], w, label='Resilience Index (R)', color='#d97706')

    ax2.set_xticks(x)
    ax2.set_xticklabels(model_labels, fontsize=9.5, fontweight='bold')
    ax2.set_ylabel("Recovery Duration (Days)", color='#2563eb', fontsize=12, fontweight='bold')
    ax2_right.set_ylabel("Resilience Index (R)", color='#d97706', fontsize=12, fontweight='bold')
    ax2_right.set_ylim(0.5, 1.05)
    ax2.set_title("Disruption Recovery Duration & Resilience", fontsize=13, fontweight='bold', pad=8)
    ax2.tick_params(labelsize=10)
    ax2_right.tick_params(labelsize=10)
    ax2.grid(False)
    ax2_right.grid(False)

    lines3, labels3 = ax2.get_legend_handles_labels()
    lines4, labels4 = ax2_right.get_legend_handles_labels()
    ax2.legend(lines3 + lines4, labels3 + labels4, loc='upper right', fontsize=9.5, frameon=True, framealpha=0.95, edgecolor='gray')

    fig.suptitle("Comparative Performance Evaluation Across Four Methodological Paradigms", fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_path = FIGURES_DIR / "framework_benchmarks_comparison.png"
    plt.savefig(out_path, dpi=800, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out_path}")


# ==============================================================================
# Plot 7 (EXTRA 1): Dynamic Multi-Echelon Inventory Trajectories
# ==============================================================================
def plot_dynamic_inventory_trajectories():
    """Plot 7: Dynamic Multi-Echelon Safety Stock and Reorder Point Trajectories."""
    inv_path = RESULTS_DIR / "dynamic_inventory_requirements.parquet"
    if not inv_path.exists():
        return
    df = pd.read_parquet(inv_path)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 7))

    # Aggregate by date and store
    daily_store = df.groupby(['date', 'store_id'])[['forecast_daily_demand', 'safety_stock', 'reorder_point']].sum().reset_index()
    daily_store['day_idx'] = daily_store.groupby('store_id').cumcount() + 1

    stores = ['CA_1', 'TX_1', 'WI_1']
    store_colors = {'CA_1': '#2563eb', 'TX_1': '#059669', 'WI_1': '#9333ea'}
    store_styles = {'CA_1': '-', 'TX_1': '--', 'WI_1': '-.'}

    # Panel 1: Dynamic Safety Stock over time across stores
    for s in stores:
        sub = daily_store[daily_store['store_id'] == s]
        ax1.plot(sub['day_idx'], sub['safety_stock'], label=f"Store {s}", color=store_colors[s], linestyle=store_styles[s], linewidth=2.4)

    ax1.set_title("Dynamic Safety Stock Trajectory Across Stores", fontsize=13, fontweight='bold', pad=8)
    ax1.set_xlabel("Horizon Day (Days 1 to 28)", fontsize=12, fontweight='bold')
    ax1.set_ylabel(r"Dynamic Safety Stock $SS_t$ (Units)", fontsize=12, fontweight='bold')
    ax1.tick_params(labelsize=10.5)
    ax1.grid(False)
    ax1.legend(loc='upper right', fontsize=10, frameon=True, framealpha=0.95, edgecolor='gray')

    # Panel 2: Reorder Point (ROP) vs Lead-Time Demand
    for s in stores:
        sub = daily_store[daily_store['store_id'] == s]
        ax2.plot(sub['day_idx'], sub['reorder_point'], label=f"Store {s} (ROP)", color=store_colors[s], linestyle=store_styles[s], linewidth=2.4)

    ax2.set_title("Dynamic Reorder Point (ROP) Dynamics", fontsize=13, fontweight='bold', pad=8)
    ax2.set_xlabel("Horizon Day (Days 1 to 28)", fontsize=12, fontweight='bold')
    ax2.set_ylabel(r"Dynamic Reorder Point $ROP_t$ (Units)", fontsize=12, fontweight='bold')
    ax2.tick_params(labelsize=10.5)
    ax2.grid(False)
    ax2.legend(loc='upper right', fontsize=10, frameon=True, framealpha=0.95, edgecolor='gray')

    fig.suptitle("Dynamic Multi-Echelon Safety Stock and Reorder Point Trajectories Across Hubs", fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_path = FIGURES_DIR / "dynamic_inventory_policy_trajectories.png"
    plt.savefig(out_path, dpi=800, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out_path}")


# ==============================================================================
# Plot 8 (EXTRA 2): Logistics Fleet Packing and Transport Cost Analysis
# ==============================================================================
def plot_logistics_fleet_analysis():
    """Plot 8: Logistics Fleet Truckload Packing Utilization and Transportation Costs."""
    sched_path = RESULTS_DIR / "logistics_shipment_schedule.csv"
    if not sched_path.exists():
        return
    df = pd.read_csv(sched_path)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 7))

    x = np.arange(len(df))
    w = 0.45
    dest_labels = [f"Store {s}\n({df.loc[i, 'transit_distance_km']} km)" for i, s in enumerate(df['destination_store'])]

    # Panel 1: Truckload Units and Capacity Utilization
    bars_units = ax1.bar(x - w/2, df['total_units_dispatched'], w, label='Dispatched Units', color='#1d4ed8')
    ax1_right = ax1.twinx()
    bars_util = ax1_right.bar(x + w/2, df['fleet_utilization_pct'], w, label='Truckload Utilization (%)', color='#059669')

    ax1.set_xticks(x)
    ax1.set_xticklabels(dest_labels, fontsize=10.5, fontweight='bold')
    ax1.set_ylabel("Dispatched Units", color='#1d4ed8', fontsize=12, fontweight='bold')
    ax1_right.set_ylabel("Capacity Utilization (%)", color='#059669', fontsize=12, fontweight='bold')
    ax1_right.set_ylim(60, 105)
    ax1.set_title("Freight Dispatched Units and Truck Utilization", fontsize=13, fontweight='bold', pad=8)
    ax1.tick_params(labelsize=10.5)
    ax1_right.tick_params(labelsize=10.5)
    ax1.grid(False)
    ax1_right.grid(False)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax1_right.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc='upper left', fontsize=9.5, frameon=True, framealpha=0.95, edgecolor='gray')

    # Panel 2: Dedicated Truck Fleet and Logistics Transit Cost
    bars_trucks = ax2.bar(x - w/2, df['trucks_required'], w, label='Dedicated Trucks Assigned', color='#d97706')
    ax2_right = ax2.twinx()
    bars_cost = ax2_right.bar(x + w/2, df['transportation_cost_usd'], w, label='Transportation Transit Cost ($)', color='#dc2626')

    ax2.set_xticks(x)
    ax2.set_xticklabels(dest_labels, fontsize=10.5, fontweight='bold')
    ax2.set_ylabel("Assigned Trucks Count", color='#d97706', fontsize=12, fontweight='bold')
    ax2_right.set_ylabel("Logistics Transit Cost ($)", color='#dc2626', fontsize=12, fontweight='bold')
    ax2.set_title("Fleet Sizing and Transportation Transit Cost", fontsize=13, fontweight='bold', pad=8)
    ax2.tick_params(labelsize=10.5)
    ax2_right.tick_params(labelsize=10.5)
    ax2.grid(False)
    ax2_right.grid(False)

    lines3, labels3 = ax2.get_legend_handles_labels()
    lines4, labels4 = ax2_right.get_legend_handles_labels()
    ax2.legend(lines3 + lines4, labels3 + labels4, loc='upper left', fontsize=9.5, frameon=True, framealpha=0.95, edgecolor='gray')

    fig.suptitle("Logistics Dispatch Schedule, Truckload Packing Utilization, and Transit Costs", fontsize=14, fontweight='bold', y=0.98)
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_path = FIGURES_DIR / "logistics_fleet_utilization_analysis.png"
    plt.savefig(out_path, dpi=800, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out_path}")


# ==============================================================================
# Plot 9 (EXTRA 3): Disruption Resilience Degradation vs Recovery Bubble Trade-off
# ==============================================================================
def plot_resilience_tradeoff_bubble():
    """Plot 9: Supply Chain Resilience Trade-off: Degradation vs Recovery Duration Across Stress Scenarios."""
    scen_csv = RESULTS_DIR / "disruption_resilience_evaluation.csv"
    if not scen_csv.exists():
        return
    df = pd.read_csv(scen_csv)

    fig, ax = plt.subplots(figsize=(11, 7))

    # Extract scenario rows (including Nominal)
    x = df['sl_degradation_pct'].values
    y = df['recovery_time_days'].values
    costs = df['total_cost_usd'].values
    resilience_indices = df['resilience_index'].values
    names = df['scenario_name'].values

    # Bubble sizes scaled to cost
    bubble_sizes = (costs / costs.max()) * 900 + 150

    scatter = ax.scatter(
        x, y,
        s=bubble_sizes,
        c=resilience_indices,
        cmap='viridis',
        alpha=0.88,
        edgecolors='black',
        linewidth=1.2
    )

    # Coordinated, collision-free annotation placement with clear pointer arrows
    annotations = {
        'Nominal Operations': {
            'xytext': (0.0, 2.3),
            'ha': 'center',
            'arrow_rad': 0.0
        },
        'Demand Surge (+60%)': {
            'xytext': (1.8, 13.0),
            'ha': 'center',
            'arrow_rad': 0.1
        },
        'Inventory Shortage (-50%)': {
            'xytext': (5.66, 8.2),
            'ha': 'center',
            'arrow_rad': -0.1
        },
        'Transportation Delay (+3 Days)': {
            'xytext': (8.1, 2.3),
            'ha': 'center',
            'arrow_rad': 0.0
        },
        'Compound Stress (Surge + Delay)': {
            'xytext': (10.02, 13.2),
            'ha': 'center',
            'arrow_rad': -0.1
        },
        'Supplier Delay (+4 Days)': {
            'xytext': (11.8, 4.0),
            'ha': 'left',
            'arrow_rad': 0.0
        }
    }

    for i, name in enumerate(names):
        cfg = annotations.get(name, {'xytext': (x[i]+0.5, y[i]+0.5), 'ha': 'center', 'arrow_rad': 0.0})
        ax.annotate(
            f"{name}\n($Cost: ${costs[i]:,.0f})",
            xy=(x[i], y[i]),
            xytext=cfg['xytext'],
            ha=cfg.get('ha', 'center'),
            va='center',
            fontsize=9.5,
            fontweight='bold',
            bbox=dict(boxstyle="round,pad=0.3", fc="white", ec="#4b5563", alpha=0.92, lw=1.0),
            arrowprops=dict(
                arrowstyle="->",
                connectionstyle=f"arc3,rad={cfg.get('arrow_rad', 0.0)}",
                color="#374151",
                lw=1.2,
                shrinkA=5,
                shrinkB=8
            )
        )

    cbar = plt.colorbar(scatter, ax=ax, pad=0.03)
    cbar.set_label("Resilience Index (R)", fontsize=13, fontweight='bold')
    cbar.ax.tick_params(labelsize=11)

    ax.set_title("Supply Chain Resilience Trade-Off: Service Degradation vs Recovery Duration", fontsize=14, fontweight='bold', pad=12)
    ax.set_xlabel(r"Service-Level Degradation ($\Delta$SL %)", fontsize=13, fontweight='bold')
    ax.set_ylabel("Recovery Duration (Days)", fontsize=13, fontweight='bold')
    ax.set_xlim(-2.2, 15.0)
    ax.set_ylim(-1.5, 15.5)
    ax.tick_params(labelsize=11)
    ax.grid(False)

    plt.tight_layout()
    out_path = FIGURES_DIR / "disruption_resilience_tradeoff_bubble.png"
    plt.savefig(out_path, dpi=800, bbox_inches='tight')
    plt.close()
    print(f"Saved: {out_path}")


def main():
    print("Generating all 9 publication-grade figures at 800 DPI with Times New Roman bold font...")
    plot_markov_matrices()
    plot_forecasting_performance()
    plot_pareto_front()
    plot_resilience_trajectories()
    plot_adaptive_vs_static()
    plot_baseline_radar_and_bars()
    # 3 Extra deep-dive plots
    plot_dynamic_inventory_trajectories()
    plot_logistics_fleet_analysis()
    plot_resilience_tradeoff_bubble()
    print("All 9 figures generated successfully at 800 DPI without grids or figure numbers!")


if __name__ == "__main__":
    main()
