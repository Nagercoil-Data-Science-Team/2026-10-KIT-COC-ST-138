"""
Step 2: Supply-Chain Feature Engineering
Captures temporal demand and operational factors affecting inventory requirements.
Techniques:
- Historical demand lag features (lag_1, lag_2, lag_7, lag_14, lag_21, lag_28)
- Rolling window statistics (rolling mean, std, min, max over 7, 14, 28 days with zero data leakage)
- Demand growth and acceleration metrics
- Price variation, price momentum, and discount depth
- Calendar and cyclical seasonal variables
- Event indicators and SNAP payment flags
- Store and product hierarchical attributes
Output: Temporal and operational feature matrix.
"""

import pandas as pd
import numpy as np
import logging
from pathlib import Path
from sklearn.preprocessing import LabelEncoder
from src.config import PREPROCESSED_DIR

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def generate_supply_chain_features(input_path=None, output_path=None):
    """
    Constructs the operational supply chain feature matrix.
    """
    logger.info("=== Starting Step 2: Supply-Chain Feature Engineering ===")
    if input_path is None:
        input_path = PREPROCESSED_DIR / "clean_sales_data.parquet"
    if output_path is None:
        output_path = PREPROCESSED_DIR / "features_sales_data.parquet"

    df = pd.read_parquet(input_path)
    df.sort_values(by=['store_id', 'item_id', 'date'], inplace=True)
    df.reset_index(drop=True, inplace=True)

    logger.info("Computing demand lag features...")
    # Group by series for lag operations
    grouped = df.groupby(['store_id', 'item_id'])['demand']

    # 1. Historical Lag Features
    lags = [1, 2, 3, 7, 14, 21, 28]
    for lag in lags:
        df[f'lag_{lag}'] = grouped.shift(lag)

    # 2. Rolling Window Statistics (Strictly shifted by 1 to prevent data leakage)
    logger.info("Computing rolling mean, std, min, max statistics...")
    shifted_demand = grouped.shift(1)
    # Using transform on shifted demand within groups
    for window in [7, 14, 28]:
        df[f'rolling_mean_{window}'] = (
            df.groupby(['store_id', 'item_id'])['demand']
            .transform(lambda s: s.shift(1).rolling(window, min_periods=1).mean())
        )
        df[f'rolling_std_{window}'] = (
            df.groupby(['store_id', 'item_id'])['demand']
            .transform(lambda s: s.shift(1).rolling(window, min_periods=1).std().fillna(0))
        )

    # Rolling min / max (7-day short-term volatility envelope)
    df['rolling_min_7'] = (
        df.groupby(['store_id', 'item_id'])['demand']
        .transform(lambda s: s.shift(1).rolling(7, min_periods=1).min())
    )
    df['rolling_max_7'] = (
        df.groupby(['store_id', 'item_id'])['demand']
        .transform(lambda s: s.shift(1).rolling(7, min_periods=1).max())
    )

    # 3. Demand Growth & Momentum
    logger.info("Computing demand growth and momentum metrics...")
    df['demand_growth_7_28'] = (
        (df['rolling_mean_7'] - df['rolling_mean_28']) / (df['rolling_mean_28'] + 1e-4)
    )
    df['demand_momentum_1_7'] = (
        (df['lag_1'] - df['lag_7']) / (df['lag_7'] + 1e-4)
    )

    # 4. Price Variation Features
    logger.info("Computing price dynamics and discount metrics...")
    df['price_rolling_mean_28'] = (
        df.groupby(['store_id', 'item_id'])['sell_price']
        .transform(lambda s: s.rolling(28, min_periods=1).mean())
    )
    df['price_ratio_28'] = df['sell_price'] / (df['price_rolling_mean_28'] + 1e-4)

    # Historical max price per item across dataset
    item_max_prices = df.groupby('item_id')['sell_price'].transform('max')
    df['price_discount_ratio'] = 1.0 - (df['sell_price'] / (item_max_prices + 1e-4))
    df['price_discount_ratio'] = df['price_discount_ratio'].clip(lower=0.0)

    # 5. Calendar Variables
    logger.info("Extracting temporal calendar and cyclical features...")
    df['date'] = pd.to_datetime(df['date'])
    df['day_of_week'] = df['date'].dt.dayofweek
    df['day_of_month'] = df['date'].dt.day
    df['week_of_year'] = df['date'].dt.isocalendar().week.astype(int)
    df['month'] = df['date'].dt.month
    df['year'] = df['date'].dt.year
    df['is_weekend'] = df['day_of_week'].isin([5, 6]).astype(int)

    # Cyclical trigonometric encodings
    df['sin_dow'] = np.sin(2 * np.pi * df['day_of_week'] / 7.0)
    df['cos_dow'] = np.cos(2 * np.pi * df['day_of_week'] / 7.0)
    df['sin_month'] = np.sin(2 * np.pi * df['month'] / 12.0)
    df['cos_month'] = np.cos(2 * np.pi * df['month'] / 12.0)

    # 6. Categorical Encodings
    logger.info("Encoding categorical store, item, department, and event features...")
    encoders = {}
    cat_columns = ['item_id', 'dept_id', 'cat_id', 'store_id', 'state_id', 'event_type_1']
    for col in cat_columns:
        le = LabelEncoder()
        df[f'{col}_enc'] = le.fit_transform(df[col].astype(str))
        encoders[col] = le

    # 7. Drop Initial Warm-up Rows (first 28 days per series due to lag_28)
    initial_rows = len(df)
    # Drop rows where lag_28 is null
    df = df.dropna(subset=['lag_28']).copy()
    df.reset_index(drop=True, inplace=True)
    logger.info("Dropped initial lag warm-up window: %d -> %d records", initial_rows, len(df))

    # 8. Save output
    df.to_parquet(output_path, index=False)
    logger.info("Feature matrix saved to %s with %d columns", output_path, len(df.columns))

    return df


if __name__ == "__main__":
    feat_df = generate_supply_chain_features()
    print("Feature Engineering completed. Columns:")
    print([c for c in feat_df.columns if 'lag' in c or 'rolling' in c or 'price' in c or 'sin' in c])
    print("Data shape:", feat_df.shape)
