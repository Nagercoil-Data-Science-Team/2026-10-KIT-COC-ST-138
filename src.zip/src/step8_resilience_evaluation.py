"""
Step 8: Supply-Chain Disruption & Resilience Evaluation
Evaluates the robustness and resilience of the optimized inventory and logistics strategy
under controlled, realistic supply-chain disruption scenarios.

Disruption Scenarios:
  1. Demand Surge: Sudden demand spike (+50% to +75% over 14 days)
  2. Supplier Delay: Upstream lead-time delay (+3 to +5 days)
  3. Transportation Delay: Transit bottleneck / transit lead time doubled
  4. Inventory Shortage: Warehouse damage / shrinkage (initial on-hand reduced by 50%)
  5. Compound Stress: Simultaneous demand surge (+40%) + supplier lead-time delay (+3 days)

Resilience Metrics:
  - Service-Level Degradation (Delta SL = SL_nominal - SL_disrupted)
  - Disrupted Stockout Rate (%)
  - Unmet Demand Units
  - Total Cost under Disruption ($)
  - Recovery Time (days to return to >= 95% nominal service level)
  - Resilience Index R = integral(SL(t)) / integral(SL_nominal)
"""

import numpy as np
import pandas as pd
import json
import logging
import sys
from pathlib import Path

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.config import (
    RESULTS_DIR, SUPPLY_CHAIN_CONFIG
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def simulate_multi_period_operations(
    replenish_plan,
    daily_demands,
    lead_times,
    simulation_days=28,
    disruption_config=None
):
    """
    Simulates daily inventory, replenishment arrivals, demand satisfaction, and costs.
    
    replenish_plan: DataFrame with store_id, item_id, recommended_order_qty, initial_on_hand, sell_price
    daily_demands: dict of (store_id, item_id) -> np.array of length simulation_days
    lead_times: dict of store_id -> base lead time in days
    disruption_config: dict specifying scenario parameters:
        - scenario_name: str
        - demand_multiplier: float or function
        - lead_time_add: int
        - transit_delay: int
        - inventory_loss_pct: float
        - disruption_start: int (e.g. day 4)
        - disruption_end: int (e.g. day 18)
    """
    if disruption_config is None:
        disruption_config = {
            "name": "Nominal",
            "demand_multiplier": 1.0,
            "lead_time_add": 0,
            "transit_delay": 0,
            "inventory_loss_pct": 0.0,
            "disruption_start": 0,
            "disruption_end": 0
        }

    d_start = disruption_config.get("disruption_start", 4)
    d_end = disruption_config.get("disruption_end", 18)
    demand_mult = disruption_config.get("demand_multiplier", 1.0)
    lt_add = disruption_config.get("lead_time_add", 0)
    transit_delay = disruption_config.get("transit_delay", 0)
    inv_loss = disruption_config.get("inventory_loss_pct", 0.0)

    holding_rate = SUPPLY_CHAIN_CONFIG["holding_cost_rate"]
    stockout_mult = SUPPLY_CHAIN_CONFIG["stockout_penalty_multiplier"]
    fixed_order_cost = SUPPLY_CHAIN_CONFIG["ordering_cost_fixed"]

    # Daily tracking structures
    daily_service_levels = []
    daily_demand_units = []
    daily_fulfilled_units = []
    daily_unmet_units = []
    daily_stockout_skus = []
    daily_holding_costs = []
    daily_stockout_costs = []
    daily_inventory_units = []

    # SKU state tracking
    # on_hand inventory per SKU
    sku_records = replenish_plan.to_dict('records')
    num_skus = len(sku_records)
    
    # Initialize inventory
    current_inventory = {}
    pending_orders = []  # list of dicts: {'store_id', 'item_id', 'qty', 'arrival_day'}

    for row in sku_records:
        key = (row['store_id'], row['item_id'])
        base_inv = row['initial_on_hand']
        # Apply initial inventory shortage if specified from start
        if inv_loss > 0 and d_start <= 0:
            base_inv = base_inv * (1.0 - inv_loss)
        current_inventory[key] = max(0.0, base_inv)

    # Initial order dispatch (placed at day 0)
    for row in sku_records:
        s_id = row['store_id']
        key = (s_id, row['item_id'])
        q_order = row['recommended_order_qty']
        if q_order > 0:
            effective_lt = lead_times.get(s_id, 3) + lt_add + transit_delay
            pending_orders.append({
                'key': key,
                'qty': q_order,
                'arrival_day': effective_lt
            })

    # Day-by-day forward simulation
    for t in range(simulation_days):
        # Check if inventory shock occurs at t == d_start
        if inv_loss > 0 and t == d_start and d_start > 0:
            for key in current_inventory:
                current_inventory[key] *= (1.0 - inv_loss)

        # 1. Receive incoming shipments scheduled for day t
        arrived_orders = [o for o in pending_orders if o['arrival_day'] == t]
        for arr in arrived_orders:
            current_inventory[arr['key']] += arr['qty']

        # 2. Process daily customer demand
        t_demand = 0.0
        t_fulfilled = 0.0
        t_unmet = 0.0
        t_stockouts = 0
        t_holding = 0.0
        t_stockout_penalty = 0.0
        t_inv_total = 0.0

        is_disrupted = (d_start <= t < d_end)

        for row in sku_records:
            key = (row['store_id'], row['item_id'])
            s_price = row['sell_price']
            
            # Base demand for this day
            d_hist = daily_demands.get(key, np.ones(simulation_days) * row['forecast_daily_demand'])
            d_t = d_hist[t % len(d_hist)]
            if is_disrupted:
                d_t *= demand_mult

            t_demand += d_t
            avail = current_inventory[key]

            if avail >= d_t:
                fulfilled = d_t
                unmet = 0.0
                current_inventory[key] = avail - d_t
            else:
                fulfilled = avail
                unmet = d_t - avail
                current_inventory[key] = 0.0
                t_stockouts += 1

            t_fulfilled += fulfilled
            t_unmet += unmet

            # End of day holding and stockout penalties
            end_stock = current_inventory[key]
            t_inv_total += end_stock
            t_holding += end_stock * (s_price * holding_rate)
            t_stockout_penalty += unmet * (s_price * stockout_mult)

        # Reorder trigger check at day 14 for second half replenishment cycle
        if t == 14:
            for row in sku_records:
                s_id = row['store_id']
                key = (s_id, row['item_id'])
                if current_inventory[key] < row['reorder_point']:
                    effective_lt = lead_times.get(s_id, 3)
                    if is_disrupted:
                        effective_lt += lt_add + transit_delay
                    pending_orders.append({
                        'key': key,
                        'qty': row['recommended_order_qty'],
                        'arrival_day': t + effective_lt
                    })

        day_sl = (t_fulfilled / t_demand) if t_demand > 0 else 1.0
        daily_service_levels.append(day_sl)
        daily_demand_units.append(t_demand)
        daily_fulfilled_units.append(t_fulfilled)
        daily_unmet_units.append(t_unmet)
        daily_stockout_skus.append(t_stockouts)
        daily_holding_costs.append(t_holding)
        daily_stockout_costs.append(t_stockout_penalty)
        daily_inventory_units.append(t_inv_total)

    # Calculate overall aggregate metrics
    total_demand = sum(daily_demand_units)
    total_fulfilled = sum(daily_fulfilled_units)
    total_unmet = sum(daily_unmet_units)
    overall_service_level = (total_fulfilled / total_demand) if total_demand > 0 else 1.0
    stockout_rate = (sum(daily_stockout_skus) / (simulation_days * num_skus)) * 100.0
    total_holding = sum(daily_holding_costs)
    total_stockout_cost = sum(daily_stockout_costs)

    # Initial ordering cost + mid-cycle ordering cost
    num_orders_placed = len(pending_orders)
    total_ordering = (num_orders_placed / max(1, num_skus)) * fixed_order_cost * 3

    # Transportation cost
    truck_cap = SUPPLY_CHAIN_CONFIG["truck_capacity_units"]
    transit_cost_km = SUPPLY_CHAIN_CONFIG["transit_cost_per_km"]
    distances = SUPPLY_CHAIN_CONFIG["distances_km"]
    total_trans = sum([
        np.ceil(o['qty'] / truck_cap) * distances.get(o['key'][0], 500) * transit_cost_km * 0.05
        for o in pending_orders
    ])

    total_cost = total_holding + total_ordering + total_trans + total_stockout_cost

    return {
        "service_level": overall_service_level,
        "stockout_rate": stockout_rate,
        "total_demand": total_demand,
        "total_fulfilled": total_fulfilled,
        "unmet_demand": total_unmet,
        "holding_cost": total_holding,
        "ordering_cost": total_ordering,
        "transportation_cost": total_trans,
        "stockout_cost": total_stockout_cost,
        "total_cost": total_cost,
        "daily_service_levels": daily_service_levels,
        "daily_inventory_units": daily_inventory_units,
        "daily_unmet_units": daily_unmet_units
    }


def evaluate_supply_chain_resilience():
    """
    Simulates baseline nominal operations vs 5 controlled disruption scenarios.
    Computes Service-Level Degradation, Recovery Time, and Resilience Index.
    """
    logger.info("=== Starting Step 8: Supply-Chain Disruption & Resilience Evaluation ===")

    replenish_plan_path = RESULTS_DIR / "selected_replenishment_plan.csv"
    if not replenish_plan_path.exists():
        raise FileNotFoundError(f"Replenishment plan not found at {replenish_plan_path}. Run Step 7 first.")

    replenish_plan = pd.read_csv(replenish_plan_path)

    # Load test predictions to build realistic 28-day daily demand traces
    pred_path = RESULTS_DIR / "forecasting_test_predictions.parquet"
    if pred_path.exists():
        pred_df = pd.read_parquet(pred_path)
        daily_demands = {}
        for (s_id, it_id), group in pred_df.groupby(['store_id', 'item_id']):
            daily_demands[(s_id, it_id)] = group['demand'].values[:28]
    else:
        daily_demands = {}
        for _, row in replenish_plan.iterrows():
            key = (row['store_id'], row['item_id'])
            daily_demands[key] = np.random.poisson(row['forecast_daily_demand'], size=28)

    lead_times = SUPPLY_CHAIN_CONFIG["lead_times"]
    simulation_days = 28
    target_service_level = SUPPLY_CHAIN_CONFIG["target_service_level"]

    # 1. Baseline Nominal Simulation
    logger.info("Running Baseline Nominal Operations Simulation...")
    nominal_sim = simulate_multi_period_operations(
        replenish_plan, daily_demands, lead_times, simulation_days=simulation_days,
        disruption_config={"name": "Nominal", "demand_multiplier": 1.0, "disruption_start": 0, "disruption_end": 0}
    )

    scenarios = [
        {
            "id": "SCEN_1",
            "name": "Demand Surge (+60%)",
            "description": "Sudden surge in customer demand by 60% during days 7-18",
            "demand_multiplier": 1.60,
            "lead_time_add": 0,
            "transit_delay": 0,
            "inventory_loss_pct": 0.0,
            "disruption_start": 7,
            "disruption_end": 18
        },
        {
            "id": "SCEN_2",
            "name": "Supplier Delay (+4 Days)",
            "description": "Upstream vendor manufacturing delay adding 4 days to replenishment lead time",
            "demand_multiplier": 1.0,
            "lead_time_add": 4,
            "transit_delay": 0,
            "inventory_loss_pct": 0.0,
            "disruption_start": 0,
            "disruption_end": 28
        },
        {
            "id": "SCEN_3",
            "name": "Transportation Delay (+3 Days)",
            "description": "Logistics transit disruption and highway congestion adding 3 days transit time",
            "demand_multiplier": 1.0,
            "lead_time_add": 0,
            "transit_delay": 3,
            "inventory_loss_pct": 0.0,
            "disruption_start": 0,
            "disruption_end": 28
        },
        {
            "id": "SCEN_4",
            "name": "Inventory Shortage (-50%)",
            "description": "Sudden warehouse stock shrinkage / damaged batches cutting inventory by 50% at day 7",
            "demand_multiplier": 1.0,
            "lead_time_add": 0,
            "transit_delay": 0,
            "inventory_loss_pct": 0.50,
            "disruption_start": 7,
            "disruption_end": 18
        },
        {
            "id": "SCEN_5",
            "name": "Compound Stress (Surge + Delay)",
            "description": "Simultaneous demand spike (+45%) and supplier lead-time delay (+3 days)",
            "demand_multiplier": 1.45,
            "lead_time_add": 3,
            "transit_delay": 0,
            "inventory_loss_pct": 0.0,
            "disruption_start": 7,
            "disruption_end": 18
        }
    ]

    scenario_results = []
    daily_trajectories = {"Day": list(range(1, simulation_days + 1))}
    daily_trajectories["Nominal_SL"] = [round(x * 100, 2) for x in nominal_sim["daily_service_levels"]]

    # Nominal baseline metrics
    nom_sl = nominal_sim["service_level"]
    nominal_integral = sum(nominal_sim["daily_service_levels"])

    scenario_results.append({
        "scenario_id": "BASE",
        "scenario_name": "Nominal Operations",
        "description": "Standard operating conditions without disruptions",
        "service_level_pct": round(nom_sl * 100, 2),
        "sl_degradation_pct": 0.0,
        "stockout_rate_pct": round(nominal_sim["stockout_rate"], 2),
        "unmet_demand_units": round(nominal_sim["unmet_demand"], 1),
        "total_cost_usd": round(nominal_sim["total_cost"], 2),
        "holding_cost_usd": round(nominal_sim["holding_cost"], 2),
        "stockout_cost_usd": round(nominal_sim["stockout_cost"], 2),
        "recovery_time_days": 0,
        "resilience_index": 1.0000
    })

    for sc in scenarios:
        logger.info("Simulating Disruption Scenario: %s...", sc["name"])
        sim_res = simulate_multi_period_operations(
            replenish_plan, daily_demands, lead_times,
            simulation_days=simulation_days, disruption_config=sc
        )

        sc_sl = sim_res["service_level"]
        sl_deg = max(0.0, (nom_sl - sc_sl) * 100)

        # Recovery time calculation: days after disruption end to return to >= 93% SL
        disr_end = sc["disruption_end"]
        rec_time = 0
        if disr_end < simulation_days and disr_end > 0:
            post_disrupt_sl = sim_res["daily_service_levels"][disr_end:]
            for idx, sl_val in enumerate(post_disrupt_sl):
                if sl_val >= 0.93:
                    rec_time = idx + 1
                    break
            else:
                rec_time = len(post_disrupt_sl) + 1
        elif sc["lead_time_add"] > 0:
            rec_time = sc["lead_time_add"] + 1

        # Resilience Index R = Area under SL curve / Area under nominal curve
        sc_integral = sum(sim_res["daily_service_levels"])
        resilience_idx = round(sc_integral / nominal_integral, 4) if nominal_integral > 0 else 0.0

        scenario_results.append({
            "scenario_id": sc["id"],
            "scenario_name": sc["name"],
            "description": sc["description"],
            "service_level_pct": round(sc_sl * 100, 2),
            "sl_degradation_pct": round(sl_deg, 2),
            "stockout_rate_pct": round(sim_res["stockout_rate"], 2),
            "unmet_demand_units": round(sim_res["unmet_demand"], 1),
            "total_cost_usd": round(sim_res["total_cost"], 2),
            "holding_cost_usd": round(sim_res["holding_cost"], 2),
            "stockout_cost_usd": round(sim_res["stockout_cost"], 2),
            "recovery_time_days": int(rec_time),
            "resilience_index": resilience_idx
        })

        daily_trajectories[f"{sc['id']}_SL"] = [round(x * 100, 2) for x in sim_res["daily_service_levels"]]

    df_results = pd.DataFrame(scenario_results)
    df_results.to_csv(RESULTS_DIR / "disruption_resilience_evaluation.csv", index=False)

    df_trajectories = pd.DataFrame(daily_trajectories)
    df_trajectories.to_csv(RESULTS_DIR / "resilience_daily_trajectories.csv", index=False)

    # Save summary metadata
    resilience_summary = {
        "nominal_service_level_pct": round(nom_sl * 100, 2),
        "scenarios_evaluated": len(scenarios),
        "mean_resilience_index": round(float(df_results.iloc[1:]['resilience_index'].mean()), 4),
        "max_service_degradation_pct": round(float(df_results.iloc[1:]['sl_degradation_pct'].max()), 2),
        "worst_scenario": str(df_results.sort_values(by="service_level_pct").iloc[0]['scenario_name']),
        "average_recovery_time_days": round(float(df_results.iloc[1:]['recovery_time_days'].mean()), 1)
    }

    with open(RESULTS_DIR / "resilience_metrics.json", "w") as f:
        json.dump(resilience_summary, f, indent=2)

    logger.info("Resilience Evaluation Completed Successfully:")
    logger.info("\n%s", df_results[['scenario_name', 'service_level_pct', 'sl_degradation_pct', 'recovery_time_days', 'resilience_index', 'total_cost_usd']].to_string(index=False))

    return df_results, df_trajectories, resilience_summary


if __name__ == "__main__":
    evaluate_supply_chain_resilience()
