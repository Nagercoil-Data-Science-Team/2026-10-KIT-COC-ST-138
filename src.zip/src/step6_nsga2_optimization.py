"""
Step 6: NSGA-II Multi-Objective Optimization
Identifies Pareto-optimal inventory replenishment and logistics shipment decisions under conflicting objectives.
Objectives:
  1. Minimize Holding Cost
  2. Minimize Ordering Cost
  3. Minimize Transportation Cost
  4. Minimize Stockout Cost
  5. Maximize Service Level (Min -Service Level)
  6. Maximize Demand Fulfillment Rate (Min -Demand Fulfillment)
Constraints:
  - Store warehouse storage capacity
  - Vehicle truckload logistics limits
Technique: NSGA-II evolutionary multi-objective optimization via pymoo.
Output: Pareto-optimal decision vectors and objective space Pareto front.
"""

import numpy as np
import pandas as pd
import json
import logging
from pathlib import Path
from pymoo.core.problem import Problem
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.optimize import minimize
from pymoo.indicators.hv import Hypervolume
from src.config import (
    RESULTS_DIR, SUPPLY_CHAIN_CONFIG, NSGA2_CONFIG
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


class SupplyChainMultiObjectiveProblem(Problem):
    def __init__(
        self,
        item_keys,
        stores,
        demands,
        holding_costs,
        sell_prices,
        stockout_penalties,
        initial_stocks,
        target_invs,
        distances,
        transit_cost_per_km,
        truck_capacity,
        fixed_order_cost,
        store_capacities
    ):
        self.item_keys = item_keys  # length N (e.g. 90)
        self.stores = stores        # length N (store corresponding to each index)
        self.unique_stores = sorted(list(set(stores)))
        self.demands = demands      # Expected demand over cycle D_i
        self.holding_costs = holding_costs
        self.sell_prices = sell_prices
        self.stockout_penalties = stockout_penalties
        self.initial_stocks = initial_stocks
        self.target_invs = target_invs
        self.distances = distances  # dict store -> km
        self.transit_cost_per_km = transit_cost_per_km
        self.truck_capacity = truck_capacity
        self.fixed_order_cost = fixed_order_cost
        self.store_capacities = store_capacities  # dict store -> max units

        n_var = len(item_keys)
        # 6 Objectives: Holding, Ordering, Transport, Stockout, -ServiceLevel, -FillRate
        n_obj = 6
        # Constraints: 1 per store for warehouse capacity
        n_constr = len(self.unique_stores)

        # Lower bound: 0 (no replenishment order)
        # Upper bound: realistic order sizing
        xl = np.zeros(n_var)
        xu = np.maximum(demands * 1.8 + target_invs * 0.4, demands + 2.0 * initial_stocks)

        super().__init__(
            n_var=n_var,
            n_obj=n_obj,
            n_ieq_constr=n_constr,
            xl=xl,
            xu=xu
        )

    def _evaluate(self, X, out, *args, **kwargs):
        # X shape: (pop_size, n_var)
        pop_size = X.shape[0]

        # Inventory after replenishment arrives: I_avail = I_0 + Q
        I_avail = self.initial_stocks[None, :] + X  # (pop_size, n_var)
        D = self.demands[None, :]                   # (pop_size, n_var)

        # 1. Holding Cost: h_i * max(0, I_avail - D / 2)
        end_inventory = np.maximum(0.0, I_avail - D * 0.5)
        f_holding = np.sum(end_inventory * self.holding_costs[None, :], axis=1)

        # 2. Ordering Cost: Fixed order cost per store placing orders + unit processing fee
        has_orders = X > 1.0  # (pop_size, n_var)
        f_ordering = np.zeros(pop_size)
        for s in self.unique_stores:
            s_mask = np.array(self.stores) == s
            store_has_order = np.any(has_orders[:, s_mask], axis=1)
            f_ordering += store_has_order * self.fixed_order_cost
        # Add small transaction cost ($1.2 per active SKU)
        f_ordering += np.sum(has_orders, axis=1) * 1.2

        # 3. Transportation Cost: distance * cost_per_km * ceil(total_units_store / truck_cap)
        f_transport = np.zeros(pop_size)
        for s in self.unique_stores:
            s_mask = np.array(self.stores) == s
            store_total_q = np.sum(X[:, s_mask], axis=1)
            num_trucks = np.ceil(store_total_q / self.truck_capacity)
            f_transport += num_trucks * self.distances[s] * self.transit_cost_per_km

        # 4. Stockout Cost: p_i * max(0, D - I_avail)
        unmet_demand = np.maximum(0.0, D - I_avail)
        f_stockout = np.sum(unmet_demand * self.stockout_penalties[None, :], axis=1)

        # 5. Service Level: Fraction of SKUs where available inventory >= demand (Maximize -> minimize negative)
        sku_fulfilled = (I_avail >= D).astype(float)
        service_level = np.mean(sku_fulfilled, axis=1)
        f_service_level = -service_level  # minimize

        # 6. Demand Fulfillment Rate (Fill Rate): sum(min(D, I_avail)) / sum(D) (Maximize -> minimize negative)
        met_demand = np.minimum(D, I_avail)
        total_demand = np.sum(self.demands) + 1e-6
        fill_rate = np.sum(met_demand, axis=1) / total_demand
        f_fill_rate = -fill_rate  # minimize

        # Constraints: sum_{i in store}(I_avail) <= StoreCapacity
        G = np.zeros((pop_size, len(self.unique_stores)))
        for idx, s in enumerate(self.unique_stores):
            s_mask = np.array(self.stores) == s
            store_total_inv = np.sum(I_avail[:, s_mask], axis=1)
            # g(x) <= 0
            G[:, idx] = store_total_inv - self.store_capacities[s]

        out["F"] = np.column_stack([
            f_holding,
            f_ordering,
            f_transport,
            f_stockout,
            f_service_level,
            f_fill_rate
        ])
        out["G"] = G


def run_nsga2_optimization(inventory_path=None):
    """Executes NSGA-II evolutionary optimization on the supply chain network."""
    logger.info("=== Starting Step 6: NSGA-II Multi-Objective Optimization ===")
    if inventory_path is None:
        inventory_path = RESULTS_DIR / "dynamic_inventory_requirements.parquet"

    df = pd.read_parquet(inventory_path)

    # Aggregate by product-store over the 7-day planning replenishment cycle
    grouped = df.groupby(['store_id', 'item_id']).agg({
        'forecast_daily_demand': 'mean',
        'sell_price': 'mean',
        'unit_holding_cost': 'mean',
        'target_inventory': 'mean',
        'safety_stock': 'mean'
    }).reset_index()

    cycle_days = 7
    grouped['cycle_demand'] = grouped['forecast_daily_demand'] * cycle_days
    # Initial on-hand stock reflects buffer around safety stock
    grouped['initial_stock'] = np.maximum(5.0, grouped['safety_stock'] * 0.75).round(0)
    grouped['stockout_penalty'] = grouped['sell_price'] * SUPPLY_CHAIN_CONFIG['stockout_penalty_multiplier']

    item_keys = [f"{row['store_id']}_{row['item_id']}" for _, row in grouped.iterrows()]
    stores = grouped['store_id'].tolist()
    demands = grouped['cycle_demand'].values
    holding_costs = grouped['unit_holding_cost'].values * cycle_days
    sell_prices = grouped['sell_price'].values
    stockout_penalties = grouped['stockout_penalty'].values
    initial_stocks = grouped['initial_stock'].values
    target_invs = grouped['target_inventory'].values

    problem = SupplyChainMultiObjectiveProblem(
        item_keys=item_keys,
        stores=stores,
        demands=demands,
        holding_costs=holding_costs,
        sell_prices=sell_prices,
        stockout_penalties=stockout_penalties,
        initial_stocks=initial_stocks,
        target_invs=target_invs,
        distances=SUPPLY_CHAIN_CONFIG['distances_km'],
        transit_cost_per_km=SUPPLY_CHAIN_CONFIG['transit_cost_per_km'],
        truck_capacity=SUPPLY_CHAIN_CONFIG['truck_capacity_units'],
        fixed_order_cost=SUPPLY_CHAIN_CONFIG['ordering_cost_fixed'],
        store_capacities=SUPPLY_CHAIN_CONFIG['store_warehouse_capacity']
    )

    algorithm = NSGA2(
        pop_size=NSGA2_CONFIG['pop_size'],
        sampling=FloatRandomSampling(),
        crossover=SBX(prob=NSGA2_CONFIG['crossover_prob'], eta=15),
        mutation=PM(prob=NSGA2_CONFIG['mutation_prob'], eta=20),
        eliminate_duplicates=True
    )

    logger.info("Executing NSGA-II (Pop size: %d, Generations: %d)...",
                NSGA2_CONFIG['pop_size'], NSGA2_CONFIG['n_gen'])

    res = minimize(
        problem,
        algorithm,
        ("n_gen", NSGA2_CONFIG['n_gen']),
        seed=NSGA2_CONFIG['seed'],
        verbose=False
    )

    # Extract non-dominated Pareto front
    if res.opt is not None and len(res.opt) > 0:
        X_pareto = res.opt.get("X")
        F_pareto = res.opt.get("F")
    elif res.F is not None:
        X_pareto = res.X
        F_pareto = res.F
    else:
        # Fallback to current population
        X_pareto = res.pop.get("X")
        F_pareto = res.pop.get("F")

    logger.info("NSGA-II Converged: Identified %d Pareto-optimal solutions.", len(F_pareto))

    # Convert objectives back to positive readable values
    # Objectives: Holding, Ordering, Transport, Stockout, Service Level (%), Fill Rate (%)
    pareto_df = pd.DataFrame({
        'Holding_Cost': F_pareto[:, 0],
        'Ordering_Cost': F_pareto[:, 1],
        'Transportation_Cost': F_pareto[:, 2],
        'Stockout_Cost': F_pareto[:, 3],
        'Service_Level': -F_pareto[:, 4],       # negate back to positive fraction
        'Demand_Fulfillment': -F_pareto[:, 5]  # negate back to positive fraction
    })
    pareto_df['Total_Cost'] = (
        pareto_df['Holding_Cost'] +
        pareto_df['Ordering_Cost'] +
        pareto_df['Transportation_Cost'] +
        pareto_df['Stockout_Cost']
    )

    # Compute Hypervolume Indicator
    # Normalize objectives into [0, 1] for hypervolume computation
    f_min = F_pareto.min(axis=0)
    f_max = F_pareto.max(axis=0)
    denom = np.where(f_max - f_min < 1e-6, 1.0, f_max - f_min)
    F_norm = (F_pareto - f_min) / denom
    ref_point = np.array([1.1, 1.1, 1.1, 1.1, 1.1, 1.1])
    hv_indicator = Hypervolume(ref_point=ref_point)
    hv_value = float(hv_indicator.do(F_norm))
    logger.info("Hypervolume (normalized against [1.1]*6): %.4f", hv_value)

    # Save Pareto results
    pareto_csv_path = RESULTS_DIR / "pareto_front_objectives.csv"
    pareto_df.to_csv(pareto_csv_path, index=False)

    np.savez_compressed(
        RESULTS_DIR / "pareto_solutions.npz",
        X_pareto=X_pareto,
        F_pareto=F_pareto,
        item_keys=np.array(item_keys),
        stores=np.array(stores)
    )

    meta = {
        "num_pareto_solutions": len(pareto_df),
        "hypervolume": round(hv_value, 4),
        "min_total_cost": round(float(pareto_df['Total_Cost'].min()), 2),
        "max_service_level": round(float(pareto_df['Service_Level'].max()), 4),
        "max_demand_fulfillment": round(float(pareto_df['Demand_Fulfillment'].max()), 4),
        "min_stockout_cost": round(float(pareto_df['Stockout_Cost'].min()), 2)
    }
    with open(RESULTS_DIR / "pareto_metrics.json", "w") as f:
        json.dump(meta, f, indent=2)

    logger.info("Pareto Front Summary: %s", meta)
    return res, pareto_df, meta


if __name__ == "__main__":
    res, p_df, m = run_nsga2_optimization()
    print("NSGA-II completed.")
    print(p_df.head())
