"""
Step 4: Markov-Enhanced XGBoost Forecasting
Generates demand forecasts combining numerical supply chain features with Markov stochastic state information.
Technique:
- XGBoost Regressor with Markov-derived features:
  * Current demand state
  * One-hot regime indicators
  * Transition probability distribution P(S_{t+1}|S_t)
  * State conditional expectation
- Comparative Baseline: Standard XGBoost (trained without Markov features)
- Forecasting evaluation: MAE, RMSE, WAPE
- Outputs: Demand forecast, residual variance, future state probabilities, feature importances.
"""

import pandas as pd
import numpy as np
import json
import joblib
import logging
from pathlib import Path
import xgboost as xgb
from sklearn.metrics import mean_absolute_error, mean_squared_error
from src.config import (
    PREPROCESSED_DIR, MODELS_DIR, RESULTS_DIR,
    TRAIN_TEST_SPLIT_DAY
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def compute_metrics(y_true, y_pred):
    """Computes MAE, RMSE, and WAPE."""
    mae = mean_absolute_error(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    sum_true = np.sum(y_true)
    wape = (np.sum(np.abs(y_true - y_pred)) / (sum_true + 1e-6)) * 100.0
    return {
        "MAE": round(float(mae), 4),
        "RMSE": round(float(rmse), 4),
        "WAPE": round(float(wape), 2)
    }


def train_forecasting_models(input_path=None):
    """
    Trains Markov-Enhanced XGBoost and Baseline Standard XGBoost.
    """
    logger.info("=== Starting Step 4: Markov-Enhanced XGBoost Forecasting ===")
    if input_path is None:
        input_path = PREPROCESSED_DIR / "markov_features_sales_data.parquet"

    df = pd.read_parquet(input_path)
    df['d_num'] = df['d'].str.replace('d_', '').astype(int)

    # Train / Test chronological split
    train_df = df[df['d_num'] <= TRAIN_TEST_SPLIT_DAY].copy()
    test_df = df[df['d_num'] > TRAIN_TEST_SPLIT_DAY].copy()

    logger.info("Chronological Split: %d train records (d <= %d) | %d test records (d > %d, final 28 days)",
                len(train_df), TRAIN_TEST_SPLIT_DAY, len(test_df), TRAIN_TEST_SPLIT_DAY)

    # Base supply chain features (common to both models)
    base_features = [
        # Lag features
        'lag_1', 'lag_2', 'lag_3', 'lag_7', 'lag_14', 'lag_21', 'lag_28',
        # Rolling statistics
        'rolling_mean_7', 'rolling_std_7', 'rolling_min_7', 'rolling_max_7',
        'rolling_mean_14', 'rolling_std_14',
        'rolling_mean_28', 'rolling_std_28',
        # Demand growth & momentum
        'demand_growth_7_28', 'demand_momentum_1_7',
        # Price dynamics
        'sell_price', 'price_rolling_mean_28', 'price_ratio_28', 'price_discount_ratio',
        # Calendar & seasonality
        'day_of_week', 'day_of_month', 'week_of_year', 'month', 'year', 'is_weekend',
        'sin_dow', 'cos_dow', 'sin_month', 'cos_month',
        # Events & promotions
        'has_event_1', 'has_event_2', 'snap_flag',
        # Categorical identifiers
        'item_id_enc', 'dept_id_enc', 'cat_id_enc', 'store_id_enc', 'state_id_enc', 'event_type_1_enc'
    ]

    # Markov stochastic features
    markov_features = [
        'markov_state',
        'state_is_low', 'state_is_normal', 'state_is_high', 'state_is_peak',
        'prob_trans_low', 'prob_trans_normal', 'prob_trans_high', 'prob_trans_peak',
        'markov_expected_demand'
    ]

    all_markov_enhanced_features = base_features + markov_features

    X_train_base = train_df[base_features]
    X_test_base = test_df[base_features]

    X_train_markov = train_df[all_markov_enhanced_features]
    X_test_markov = test_df[all_markov_enhanced_features]

    y_train = train_df['demand'].values
    y_test = test_df['demand'].values

    # 1. Train Baseline Standard XGBoost (without Markov)
    logger.info("Training Baseline Standard XGBoost (Features: %d)...", len(base_features))
    xgb_baseline = xgb.XGBRegressor(
        n_estimators=150,
        max_depth=6,
        learning_rate=0.07,
        subsample=0.85,
        colsample_bytree=0.85,
        random_state=42,
        n_jobs=-1
    )
    xgb_baseline.fit(X_train_base, y_train)
    y_pred_base = np.clip(xgb_baseline.predict(X_test_base), 0, None)
    metrics_base = compute_metrics(y_test, y_pred_base)
    logger.info("Baseline XGBoost Test Performance: %s", metrics_base)

    # 2. Train Proposed Markov-Enhanced XGBoost
    logger.info("Training Proposed Markov-Enhanced XGBoost (Features: %d)...", len(all_markov_enhanced_features))
    xgb_markov = xgb.XGBRegressor(
        n_estimators=180,
        max_depth=6,
        learning_rate=0.06,
        subsample=0.85,
        colsample_bytree=0.85,
        random_state=42,
        n_jobs=-1
    )
    xgb_markov.fit(X_train_markov, y_train)
    y_pred_markov = np.clip(xgb_markov.predict(X_test_markov), 0, None)
    metrics_markov = compute_metrics(y_test, y_pred_markov)
    logger.info("Markov-Enhanced XGBoost Test Performance: %s", metrics_markov)

    # 3. Calculate Forecasting Residuals and Error Variances per Product-Store
    test_df['y_true'] = y_test
    test_df['y_pred_base'] = y_pred_base
    test_df['y_pred_markov'] = y_pred_markov
    test_df['residual_markov'] = y_test - y_pred_markov

    # Per-series residual variance & sigma_e
    series_residuals = (
        test_df.groupby(['store_id', 'item_id'])['residual_markov']
        .agg(residual_std=lambda x: float(np.std(x)),
             residual_mean=lambda x: float(np.mean(x)))
        .reset_index()
    )

    # Feature Importance analysis
    feature_importance = pd.DataFrame({
        'feature': all_markov_enhanced_features,
        'importance': xgb_markov.feature_importances_
    }).sort_values(by='importance', ascending=False)

    logger.info("Top 10 Important Features in Markov-Enhanced XGBoost:")
    for _, row in feature_importance.head(10).iterrows():
        logger.info("  %-25s: %.4f", row['feature'], row['importance'])

    # Save models and artifacts
    joblib.dump(xgb_baseline, MODELS_DIR / "xgboost_baseline.joblib")
    joblib.dump(xgb_markov, MODELS_DIR / "xgboost_markov_enhanced.joblib")

    # Save test predictions for downstream optimization & evaluation
    predictions_path = RESULTS_DIR / "forecasting_test_predictions.parquet"
    test_df.to_parquet(predictions_path, index=False)

    feature_importance.to_csv(RESULTS_DIR / "feature_importance.csv", index=False)
    series_residuals.to_csv(RESULTS_DIR / "series_residuals.csv", index=False)

    results_summary = {
        "baseline_xgboost": metrics_base,
        "markov_enhanced_xgboost": metrics_markov,
        "relative_improvement_wape_pct": round(
            float((metrics_base["WAPE"] - metrics_markov["WAPE"]) / metrics_base["WAPE"] * 100), 2
        ),
        "relative_improvement_rmse_pct": round(
            float((metrics_base["RMSE"] - metrics_markov["RMSE"]) / metrics_base["RMSE"] * 100), 2
        )
    }
    with open(RESULTS_DIR / "forecasting_metrics.json", "w") as f:
        json.dump(results_summary, f, indent=2)

    logger.info("Forecasting Evaluation Summary: %s", results_summary)

    return xgb_markov, test_df, results_summary


if __name__ == "__main__":
    model, test_df, summary = train_forecasting_models()
    print("Forecasting finished successfully.")
    print("Metrics:", summary)
